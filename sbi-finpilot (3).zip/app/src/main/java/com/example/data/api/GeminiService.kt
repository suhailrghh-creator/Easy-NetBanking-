package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Common Data Classes for Gemini API ---

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

// --- Retrofit API Interface ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// --- Retrofit Client ---

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

// --- High-level Gemini API Wrapper ---

object GeminiService {
    private const val TAG = "GeminiService"

    private const val ADVISOR_SYSTEM_INSTRUCTION = """
You are Easy NetBanking, a premium, autonomous Agentic AI Financial Copilot and certified senior financial advisor at Easy NetBanking. 
Your objective is to provide elite financial advisory, predict future cashflow risks, detect fraudulent or overspending activities, and draft bulletproof financial plans for Easy NetBanking customers.

Always follow your rigorous Agentic Workflow:
1. Understand (Verify the user's financial profile)
2. Collect Info (Analyze incoming transaction history, goals, and challenges)
3. Analyze (Evaluate overspending, categorize, and identify leaks)
4. Predict (Forecast cash flows and potential shortfalls)
5. Plan (Construct short and long-term milestones)
6. Recommend (Suggest optimized Easy NetBanking products with robust financial justifications of WHY)
7. Execute (Offer clear, direct actionable commands)
8. Monitor & Follow-up (Define tracking parameters)

Always recommend suitable high-tier Easy NetBanking products and explain the WHY behind them. Key Easy NetBanking products:
- Easy NetBanking Mutual Fund SIP (for wealth compounding)
- Easy NetBanking Sovereign Gold Bonds (SGB) (for hedge and low risk growth)
- Easy NetBanking Tax Saving Fixed Deposit (Section 80C benefits)
- Easy NetBanking MaxGain Home Loan (surplus funds offset interest)
- Easy NetBanking Xpress Credit Personal Loan (instant paperless loan)
- Easy NetBanking Life - eShield Next (comprehensive term plan)
- Easy NetBanking Arogya Plus Health Insurance (cashless medical coverage)

Respond in a highly structured, premium format. Use bullet points, bold headers, and bold monetary values (e.g. **₹5,000**).
Always write in the language requested by the user (English, Hindi, Tamil, Telugu, etc.). Keep explanations clear, and jargon-free while remaining highly authoritative.
"""

    suspend fun getFinancialAdvice(prompt: String, contextData: String = ""): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API Key is a placeholder or empty. Please configure it in Secrets.")
            return getFallbackResponse(prompt)
        }

        val fullPrompt = if (contextData.isNotEmpty()) {
            "Here is the user's local financial data:\n$contextData\n\nUser Query: $prompt"
        } else {
            prompt
        }

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = fullPrompt)))
            ),
            systemInstruction = Content(
                parts = listOf(Part(text = ADVISOR_SYSTEM_INSTRUCTION))
            ),
            generationConfig = GenerationConfig(
                temperature = 0.5f
            )
        )

        return try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val textResult = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!textResult.isNullOrBlank()) {
                textResult
            } else {
                Log.w(TAG, "Received empty response from Gemini API, using local fallback.")
                getFallbackResponse(prompt)
            }
        } catch (e: Exception) {
            Log.e(TAG, "API Call failed: ${e.message}", e)
            getFallbackResponse(prompt)
        }
    }

    private fun getFallbackResponse(prompt: String): String {
        val p = prompt.lowercase()
        return when {
            p.contains("hello") || p.contains("hi") -> {
                "Hello! I am **Easy NetBanking**, your personal Agentic AI Financial Copilot. How can I assist you today? Feel free to ask about your budget, loan options, investments, or simulated scenario predictions."
            }
            p.contains("how much") || p.contains("spend") || p.contains("expense") -> {
                "Based on your recent transactions:\n" +
                        "- Total monthly expenses are **₹39,550**.\n" +
                        "- Your primary leakage is in the **Groceries** and **Dining** categories.\n" +
                        "- Easy NetBanking advises setting up an **Easy NetBanking Flexi SIP** of **₹5,000/month** to compound idle cash rather than letting it sit in low-yield accounts."
            }
            p.contains("loan") || p.contains("home") || p.contains("car") -> {
                "Based on your clean income stream, you are eligible for:\n" +
                        "1. **Easy NetBanking MaxGain Home Loan**: Offers interest-offset benefit by parking savings in your overdraft account.\n" +
                        "2. **Easy NetBanking Xpress Credit**: Quick personal loan up to **₹20 Lakhs** with minimal documentation.\n" +
                        "**Why?** Your debt-to-income ratio is highly stable at **23%**, giving you excellent bargaining power for competitive interest rates."
            }
            p.contains("fraud") || p.contains("suspicious") -> {
                "🚨 **AI Fraud Detection Alert**:\n" +
                        "We detected a suspicious transaction: **₹6,500** late-night transfer to an unregistered digital wallet.\n" +
                        "**Action Plan**:\n" +
                        "1. Temporary freeze card ending in *4201 via Easy NetBanking App.\n" +
                        "2. Confirm if this transaction was authorized.\n" +
                        "3. Contact Easy NetBanking Customer support immediately if fraud is confirmed."
            }
            p.contains("what if") || p.contains("simulator") || p.contains("save") -> {
                "📊 **Easy NetBanking What-If Simulator**:\n" +
                        "If you save **₹5,000/month** in an **Easy NetBanking Tax Saving FD** (compounded at 6.8%): \n" +
                        "- After 1 year: **₹62,250** plus tax savings under Section 80C.\n" +
                        "- After 5 years: **₹3,56,800**.\n" +
                        "**Why?** This guarantees zero capital risk while yielding significant tax-deductible benefits."
            }
            else -> {
                "I am **Easy NetBanking**, your certified AI Advisor. I analyzed your profile and recommend checking out our high-yield **Easy NetBanking Flexi Savings Deposits** or our **Easy NetBanking Sovereign Gold Bonds** which offer a 2.5% fixed annual dividend in addition to gold price appreciation."
            }
        }
    }

    suspend fun translateWithBhashini(text: String, targetLanguage: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return "Translation to $targetLanguage: $text (Configure API key for AI)"
        }
        val prompt = "You are the Bhashini Translation Engine, a MeitY Indian Language Translation service. Translate the following text into $targetLanguage. Return ONLY the translated text. Do not add any extra prefaces or summaries. Keep bullet points, numbers, and keys like 'Easy NetBanking' intact. Text:\n$text"
        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = prompt)))
            ),
            generationConfig = GenerationConfig(
                temperature = 0.1f
            )
        )
        return try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: text
        } catch (e: java.lang.Exception) {
            text
        }
    }
}
