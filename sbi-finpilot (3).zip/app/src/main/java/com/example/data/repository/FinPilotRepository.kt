package com.example.data.repository

import com.example.data.local.TransactionDao
import com.example.data.local.SavingGoalDao
import com.example.data.local.UserProfileDao
import com.example.data.local.FinancialChallengeDao
import com.example.data.model.FinancialChallenge
import com.example.data.model.SavingGoal
import com.example.data.model.Transaction
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class FinPilotRepository(
    private val transactionDao: TransactionDao,
    private val savingGoalDao: SavingGoalDao,
    private val userProfileDao: UserProfileDao,
    private val financialChallengeDao: FinancialChallengeDao
) {
    fun getTransactionsForUser(userId: String): Flow<List<Transaction>> = 
        transactionDao.getAllTransactions(userId)

    fun getGoalsForUser(userId: String): Flow<List<SavingGoal>> = 
        savingGoalDao.getAllGoals(userId)

    fun getUserProfile(userId: String): Flow<UserProfile?> = 
        userProfileDao.getUserProfile(userId)

    fun getChallengesForUser(userId: String): Flow<List<FinancialChallenge>> = 
        financialChallengeDao.getAllChallenges(userId)

    suspend fun getUserProfileOnce(userId: String): UserProfile? = 
        userProfileDao.getUserProfileOnce(userId)

    suspend fun insertTransaction(transaction: Transaction) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun insertTransactions(transactions: List<Transaction>) {
        transactionDao.insertTransactions(transactions)
    }

    suspend fun updateTransaction(transaction: Transaction) {
        transactionDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    suspend fun deleteAllTransactions(userId: String) {
        transactionDao.deleteAllTransactions(userId)
    }

    suspend fun insertGoal(goal: SavingGoal) {
        savingGoalDao.insertGoal(goal)
    }

    suspend fun updateGoal(goal: SavingGoal) {
        savingGoalDao.updateGoal(goal)
    }

    suspend fun deleteGoal(goal: SavingGoal) {
        savingGoalDao.deleteGoal(goal)
    }

    suspend fun updateProfile(profile: UserProfile) {
        userProfileDao.insertUserProfile(profile)
    }

    suspend fun updateChallenge(challenge: FinancialChallenge) {
        financialChallengeDao.updateChallenge(challenge)
    }

    suspend fun insertChallenge(challenge: FinancialChallenge) {
        financialChallengeDao.insertChallenge(challenge)
    }

    suspend fun populateDemoDataForUser(userId: String, fullName: String, email: String, phone: String, pinCode: String) {
        val currentProfile = userProfileDao.getUserProfileOnce(userId)
        if (currentProfile == null) {
            val defaultProfile = UserProfile(
                id = userId,
                pinCode = pinCode,
                fullName = fullName,
                email = email,
                phone = phone,
                healthScore = 82,
                language = "English",
                themeMode = "DARK"
            )
            userProfileDao.insertUserProfile(defaultProfile)

            val cal = Calendar.getInstance()
            val now = cal.timeInMillis

            val sampleTransactions = listOf(
                Transaction(
                    userId = userId,
                    title = "Monthly Salary Credited",
                    amount = 95000.0,
                    type = "INCOME",
                    category = "Salary",
                    timestamp = now - (2 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "SBI Flexi SIP Mutual Fund",
                    amount = 12000.0,
                    type = "EXPENSE",
                    category = "Investment",
                    timestamp = now - (24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Rent Income - Flat 2B",
                    amount = 18000.0,
                    type = "INCOME",
                    category = "Rent",
                    timestamp = now - (5 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Smart Bazaar Grocery Shopping",
                    amount = 4500.0,
                    type = "EXPENSE",
                    category = "Groceries",
                    timestamp = now - (6 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Bescom Electricity Bill",
                    amount = 2300.0,
                    type = "EXPENSE",
                    category = "Utilities",
                    timestamp = now - (3 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "SBI Platinum Credit Card Payment",
                    amount = 9400.0,
                    type = "EXPENSE",
                    category = "Bills",
                    timestamp = now - (4 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "HDFC Home Loan EMI",
                    amount = 22000.0,
                    type = "EXPENSE",
                    category = "EMI/Loan",
                    timestamp = now - (10 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Swiggy Gourmet Order",
                    amount = 1850.0,
                    type = "EXPENSE",
                    category = "Dining",
                    timestamp = now - (12 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Suspicious Digital Transfer #7240",
                    amount = 6500.0,
                    type = "EXPENSE",
                    category = "Shopping",
                    timestamp = now - (18 * 3600 * 1000),
                    isSuspicious = true,
                    notes = "Suspicious transfer detected late night to an unregistered wallet."
                ),
                Transaction(
                    userId = userId,
                    title = "Amazon India Retail Purchase",
                    amount = 3500.0,
                    type = "EXPENSE",
                    category = "Shopping",
                    timestamp = now - (3 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Uber Auto Ride",
                    amount = 120.0,
                    type = "EXPENSE",
                    category = "Travel",
                    timestamp = now - (2 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Starbucks Bangalore Coffee",
                    amount = 480.0,
                    type = "EXPENSE",
                    category = "Dining",
                    timestamp = now - (4 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "SBI Card Cashback Reward",
                    amount = 750.0,
                    type = "INCOME",
                    category = "Others",
                    timestamp = now - (5 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Zomato Biryani Order",
                    amount = 650.0,
                    type = "EXPENSE",
                    category = "Dining",
                    timestamp = now - (6 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Cult.fit Gym Subscription",
                    amount = 3600.0,
                    type = "EXPENSE",
                    category = "Health",
                    timestamp = now - (8 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Netflix Monthly Premium",
                    amount = 649.0,
                    type = "EXPENSE",
                    category = "Utilities",
                    timestamp = now - (9 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "BookMyShow Ticket Booking",
                    amount = 820.0,
                    type = "EXPENSE",
                    category = "Entertainment",
                    timestamp = now - (11 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "Airtel Fiber Broadband Bill",
                    amount = 1179.0,
                    type = "EXPENSE",
                    category = "Utilities",
                    timestamp = now - (13 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "SBI Fixed Deposit Interest Pay",
                    amount = 5400.0,
                    type = "INCOME",
                    category = "Investment",
                    timestamp = now - (14 * 24 * 3600 * 1000)
                ),
                Transaction(
                    userId = userId,
                    title = "SBI Securities Shares Purchase",
                    amount = 15000.0,
                    type = "EXPENSE",
                    category = "Investment",
                    timestamp = now - (15 * 24 * 3600 * 1000)
                )
            )
            transactionDao.insertTransactions(sampleTransactions)

            val sampleGoals = listOf(
                SavingGoal(
                    userId = userId,
                    name = "SBI Sovereign Gold Bond",
                    targetAmount = 150000.0,
                    currentAmount = 90000.0,
                    deadline = "31 Dec 2026"
                ),
                SavingGoal(
                    userId = userId,
                    name = "Emergency Reserve Fund",
                    targetAmount = 250000.0,
                    currentAmount = 180000.0,
                    deadline = "15 Oct 2026"
                ),
                SavingGoal(
                    userId = userId,
                    name = "Retirement SIP Corpus",
                    targetAmount = 1000000.0,
                    currentAmount = 120000.0,
                    deadline = "01 Jan 2035"
                )
            )
            savingGoalDao.insertGoals(sampleGoals)

            val sampleChallenges = listOf(
                FinancialChallenge(
                    userId = userId,
                    title = "30-Day Savings Challenge",
                    description = "Maintain non-essential spending below ₹500/day for 30 consecutive days.",
                    durationDays = 30,
                    progress = 0.73f,
                    isCompleted = false,
                    rewardPoints = 250
                ),
                FinancialChallenge(
                    userId = userId,
                    title = "No-Spend Weekend Challenge",
                    description = "Spend only on critical utilities and food during the weekend.",
                    durationDays = 2,
                    progress = 1.0f,
                    isCompleted = true,
                    rewardPoints = 150
                ),
                FinancialChallenge(
                    userId = userId,
                    title = "Emergency Fund Multiplier",
                    description = "Top up your emergency savings by an additional ₹10,000 this month.",
                    durationDays = 15,
                    progress = 0.40f,
                    isCompleted = false,
                    rewardPoints = 300
                )
            )
            financialChallengeDao.insertChallenges(sampleChallenges)
        }
    }
}
