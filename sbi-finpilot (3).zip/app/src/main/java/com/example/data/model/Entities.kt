package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "suhail",
    val title: String,
    val amount: Double,
    val type: String, // "INCOME" or "EXPENSE"
    val category: String,
    val timestamp: Long,
    val isSuspicious: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "saving_goals")
data class SavingGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "suhail",
    val name: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val deadline: String
)

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val id: String = "suhail",
    val pinCode: String = "1234",
    val fullName: String = "Suhail Rahman",
    val email: String = "suhailrghh@gmail.com",
    val phone: String = "+91 9876543210",
    val healthScore: Int = 78,
    val language: String = "English",
    val themeMode: String = "DARK", // "LIGHT", "DARK", "SYSTEM"
    val pinLockEnabled: Boolean = false,
    val biometricsEnabled: Boolean = false,
    val familyModeEnabled: Boolean = false,
    val businessModeEnabled: Boolean = false,
    val farmerModeEnabled: Boolean = false,
    val studentModeEnabled: Boolean = false,
    val seniorCitizenModeEnabled: Boolean = false
)

@Entity(tableName = "challenges")
data class FinancialChallenge(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "suhail",
    val title: String,
    val description: String,
    val durationDays: Int,
    val progress: Float, // 0.0f to 1.0f
    val isCompleted: Boolean = false,
    val rewardPoints: Int = 100
)
