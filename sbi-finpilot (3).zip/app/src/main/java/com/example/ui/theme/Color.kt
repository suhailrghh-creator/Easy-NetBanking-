package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Easy NetBanking & FinTech Color Palette
val SbiBlue = Color(0xFF0063A6)      // Signature Easy NetBanking Royal Blue
val SbiLightBlue = Color(0xFF00A3E0) // Premium Tech Teal/Blue
val SbiGold = Color(0xFFF2A900)      // Accent Gold for VIP banking
val SbiSuccess = Color(0xFF2E7D32)   // Rich green for credits/income
val SbiError = Color(0xFFC62828)     // Deep red for debits/fraud alerts

// Dark Theme Slate & Onyx
val SbiDarkBg = Color(0xFF0A0F1D)        // Ultra deep navy space back
val SbiDarkSurface = Color(0xFF12192C)   // Deep slate surface
val SbiDarkCard = Color(0xFF1B243D)      // Soft Glassmorphic Card
val SbiDarkBorder = Color(0xFF2C395B)    // Border/Outline
val SbiOnDarkText = Color(0xFFF1F5F9)    // Bright Slate text
val SbiOnDarkSub = Color(0xFF94A3B8)     // Muted Slate text

// Light Theme Slate & Pearl
val SbiLightBg = Color(0xFFF8FAFC)       // Pearl white
val SbiLightSurface = Color(0xFFFFFFFF)  // Clean white
val SbiLightCard = Color(0xFFEDF2F7)     // Premium soft gray
val SbiLightBorder = Color(0xFFCBD5E1)   // Light gray border
val SbiOnLightText = Color(0xFF0F172A)   // Dark Slate text
val SbiOnLightSub = Color(0xFF64748B)    // Muted dark text
