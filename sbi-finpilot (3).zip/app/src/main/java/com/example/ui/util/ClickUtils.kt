package com.example.ui.util

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.semantics.Role

/**
 * Click Debouncer to prevent rapid multiple clicks (double click glitch) and simultaneous multi-touch.
 */
class ClickDebouncer(private val delayMillis: Long = 500L) {
    companion object {
        @Volatile
        private var globalLastClickTime = 0L

        @Synchronized
        fun processGlobalEvent(delayMillis: Long, event: () -> Unit) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - globalLastClickTime >= delayMillis) {
                globalLastClickTime = currentTime
                event()
            }
        }
    }

    fun processEvent(event: () -> Unit) {
        processGlobalEvent(delayMillis, event)
    }
}

/**
 * A Composable helper that remembers a click debouncer and returns a safe click lambda.
 */
@Composable
fun debounced(
    delayMillis: Long = 500L,
    onClick: () -> Unit
): () -> Unit {
    val clickDebouncer = remember { ClickDebouncer(delayMillis) }
    return remember(onClick) {
        {
            clickDebouncer.processEvent(onClick)
        }
    }
}

/**
 * A custom modifier that applies clickable with click debouncing.
 */
fun Modifier.debouncedClickable(
    enabled: Boolean = true,
    delayMillis: Long = 500L,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit
): Modifier = composed {
    val clickDebouncer = remember { ClickDebouncer(delayMillis) }
    this.clickable(
        enabled = enabled,
        onClickLabel = onClickLabel,
        role = role,
        onClick = {
            clickDebouncer.processEvent(onClick)
        }
    )
}
