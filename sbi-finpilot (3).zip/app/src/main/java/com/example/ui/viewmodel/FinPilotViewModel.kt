package com.example.ui.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.FinancialChallenge
import com.example.data.model.SavingGoal
import com.example.data.model.Transaction
import com.example.data.model.UserProfile
import com.example.data.repository.FinPilotRepository
import com.example.data.api.GeminiService
import com.example.data.api.LanguageTranslations
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import android.content.Context
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.content.Intent

data class NotificationItem(
    val id: String,
    val title: String,
    val description: String,
    val type: String, // "FRAUD", "BUDGET", "GOAL", "OFFER"
    val time: String,
    val priority: String // "HIGH", "MEDIUM", "LOW"
)

class FinPilotViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val db = AppDatabase.getInstance(application)
    private val repository = FinPilotRepository(
        db.transactionDao(),
        db.savingGoalDao(),
        db.userProfileDao(),
        db.financialChallengeDao()
    )

    // TTS Engine
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    // Authentication and Nav Session State
    val isLoggedIn = MutableStateFlow(false)
    val currentUserId = MutableStateFlow("") // Active logged in user ID
    val authError = MutableStateFlow<String?>(null)
    val currentTab = MutableStateFlow(0) // 0: Dash, 1: AI, 2: Tools, 3: Settings
    val activeAuthScreen = MutableStateFlow("LOGIN") // "LOGIN", "SIGNUP", "FORGOT", "OTP"
    val showPinScreen = MutableStateFlow(false)
    val enterPinCode = MutableStateFlow("")

    // Database Flows (Isolated per User)
    @OptIn(ExperimentalCoroutinesApi::class)
    val transactions: StateFlow<List<Transaction>> = currentUserId
        .flatMapLatest { userId ->
            if (userId.isEmpty()) flowOf(emptyList())
            else repository.getTransactionsForUser(userId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val goals: StateFlow<List<SavingGoal>> = currentUserId
        .flatMapLatest { userId ->
            if (userId.isEmpty()) flowOf(emptyList())
            else repository.getGoalsForUser(userId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val challenges: StateFlow<List<FinancialChallenge>> = currentUserId
        .flatMapLatest { userId ->
            if (userId.isEmpty()) flowOf(emptyList())
            else repository.getChallengesForUser(userId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val userProfile: StateFlow<UserProfile?> = currentUserId
        .flatMapLatest { userId ->
            if (userId.isEmpty()) flowOf(null)
            else repository.getUserProfile(userId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // UI/Preferences local cache
    val selectedLanguage = MutableStateFlow("English")
    val isDarkMode = MutableStateFlow(true)
    val isVoiceEnabled = MutableStateFlow(true)

    // Copilot Dialogue States
    private val _chatMessages = MutableStateFlow<List<Pair<String, Boolean>>>(emptyList())
    val chatMessages: StateFlow<List<Pair<String, Boolean>>> = _chatMessages.asStateFlow()
    val isChatLoading = MutableStateFlow(false)

    // Advanced AI Bhashini Translations Map (index of message to translated text)
    val chatTranslations = MutableStateFlow<Map<Int, String>>(emptyMap())
    val isTranslationLoading = MutableStateFlow<Int?>(null) // index currently translating

    // Swipeable / Skippable Notifications Queue
    val notifications = MutableStateFlow<List<NotificationItem>>(emptyList())

    // Active AI Call Assistant Overlay State
    val isCallActive = MutableStateFlow(false)
    val callTranscript = MutableStateFlow<List<Pair<String, Boolean>>>(emptyList())
    val isCallSpeaking = MutableStateFlow(false)

    // --- Real-time Voice & Biometrics Persistence cache ---
    private val prefs = application.getSharedPreferences("easy_netbanking_finpilot_prefs", Context.MODE_PRIVATE)
    
    private var speechRecognizer: SpeechRecognizer? = null
    val isListening = MutableStateFlow(false)
    val recognizedText = MutableStateFlow("")

    fun setLastLoggedInUser(username: String) {
        prefs.edit().putString("last_username", username).apply()
    }

    fun getLastLoggedInUser(): String {
        return prefs.getString("last_username", "") ?: ""
    }

    fun startListening(context: Context) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e("SpeechRecognizer", "Speech recognition is not available on this device")
            return
        }
        viewModelScope.launch(Dispatchers.Main) {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(object : RecognitionListener {
                            override fun onReadyForSpeech(params: android.os.Bundle?) {
                                isListening.value = true
                                recognizedText.value = ""
                            }
                            override fun onBeginningOfSpeech() {}
                            override fun onRmsChanged(rmsdB: Float) {}
                            override fun onBufferReceived(buffer: ByteArray?) {}
                            override fun onEndOfSpeech() {
                                isListening.value = false
                            }
                            override fun onError(error: Int) {
                                isListening.value = false
                                val errorMessage = when (error) {
                                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                                    SpeechRecognizer.ERROR_CLIENT -> "Client-side error"
                                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissions missing"
                                    SpeechRecognizer.ERROR_NETWORK -> "Network error"
                                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service busy"
                                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
                                    else -> "Unknown speech error"
                                }
                                Log.e("SpeechRecognizer", "Error: $errorMessage ($error)")
                            }
                            override fun onResults(results: android.os.Bundle?) {
                                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                if (!matches.isNullOrEmpty()) {
                                    val transcribed = matches[0]
                                    recognizedText.value = transcribed
                                    handleVoiceCommand(transcribed)
                                }
                            }
                            override fun onPartialResults(partialResults: android.os.Bundle?) {}
                            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                        })
                    }
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                }
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("SpeechRecognizer", "Error starting SpeechRecognizer", e)
                isListening.value = false
            }
        }
    }

    fun stopListening() {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                speechRecognizer?.stopListening()
                isListening.value = false
            } catch (e: Exception) {
                Log.e("SpeechRecognizer", "Error stopping SpeechRecognizer", e)
            }
        }
    }

    fun toggleSpeechListening(context: Context) {
        if (isListening.value) {
            stopListening()
        } else {
            startListening(context)
        }
    }

    fun performBiometricLogin(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val lastUser = getLastLoggedInUser()
            if (lastUser.isEmpty()) {
                onResult(false, "No previous user found on this device. Please log in with PIN first.")
                return@launch
            }
            val profile = repository.getUserProfileOnce(lastUser)
            if (profile != null && profile.biometricsEnabled) {
                currentUserId.value = lastUser
                isLoggedIn.value = true
                showPinScreen.value = false
                chatTranslations.value = emptyMap()
                _chatMessages.value = listOf(
                    LanguageTranslations.get(profile.language, "copilot_welcome") to false
                )
                setupDemoNotifications()
                onResult(true, "Successfully authenticated as ${profile.fullName}")
            } else {
                onResult(false, "Biometric login is not enabled for $lastUser. Please log in with PIN and enable it in Settings.")
            }
        }
    }

    // Simulator inputs & outputs
    val simSaveAmount = MutableStateFlow("5000")
    val simReduceFood = MutableStateFlow("2000")
    val simLoanAmount = MutableStateFlow("1000000")
    val simResult = MutableStateFlow("")
    val isSimLoading = MutableStateFlow(false)

    // Specialized calculators
    val emiLoanAmount = MutableStateFlow("1000000")
    val emiInterestRate = MutableStateFlow("8.5")
    val emiTenureYears = MutableStateFlow("15")
    val emiResult = MutableStateFlow("₹9,847 / month")

    // Dedicated Bhashini Translator Box Inputs
    val bhashiniSourceText = MutableStateFlow("")
    val bhashiniTargetLanguage = MutableStateFlow("Hindi")
    val bhashiniTranslatedText = MutableStateFlow("")
    val isBhashiniTranslating = MutableStateFlow(false)

    init {
        // Initialize TextToSpeech
        tts = TextToSpeech(application, this)

        viewModelScope.launch {
            // Auto register a default demo account "suhail" (PIN: 1234) on first launch so the user can easily log in
            repository.populateDemoDataForUser(
                userId = "suhail",
                fullName = "Suhail Rahman",
                email = "suhailrghh@gmail.com",
                phone = "+91 9876543210",
                pinCode = "1234"
            )

            // Auto redirect to PIN_UNLOCK at startup if PIN/Biometrics lock is enabled
            val lastUser = getLastLoggedInUser()
            if (lastUser.isNotEmpty()) {
                val profile = repository.getUserProfileOnce(lastUser)
                if (profile != null && (profile.pinLockEnabled || profile.biometricsEnabled)) {
                    activeAuthScreen.value = "PIN_UNLOCK"
                }
            }

            // Synchronize UI preferences from DB state dynamically
            userProfile.collectLatest { profile ->
                profile?.let {
                    selectedLanguage.value = it.language
                    isDarkMode.value = it.themeMode == "DARK"
                    // Add default welcome message in selected language
                    if (_chatMessages.value.isEmpty()) {
                        _chatMessages.value = listOf(
                            LanguageTranslations.get(it.language, "copilot_welcome") to false
                        )
                    }
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let {
                val result = it.setLanguage(Locale.US)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("TTS", "Language is not supported or missing data")
                } else {
                    isTtsReady = true
                }
            }
        } else {
            Log.e("TTS", "Initialization failed")
        }
    }

    fun speak(text: String) {
        if (isVoiceEnabled.value && isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "EasyNetBanking_TTS")
        }
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    // --- Authentication Actions ---
    fun performLogin(username: String, pin: String) {
        if (username.isBlank() || pin.isBlank()) {
            authError.value = "Username and PIN cannot be empty"
            return
        }
        val trimmedUser = username.trim().lowercase()
        val originalName = username.trim()
        viewModelScope.launch {
            val profile = repository.getUserProfileOnce(trimmedUser)
            if (profile != null) {
                if (profile.pinCode == pin) {
                    authError.value = null
                    currentUserId.value = trimmedUser
                    isLoggedIn.value = true
                    showPinScreen.value = false
                    
                    // Clear state for user
                    chatTranslations.value = emptyMap()
                    _chatMessages.value = listOf(
                        LanguageTranslations.get(profile.language, "copilot_welcome") to false
                    )
                    
                    // Setup beautiful notifications queue for individual user
                    setupDemoNotifications()
                } else {
                    authError.value = "Invalid PIN for $originalName"
                }
            } else {
                // Auto-register the new user with the name they entered!
                repository.populateDemoDataForUser(
                    userId = trimmedUser,
                    pinCode = pin,
                    fullName = originalName,
                    email = "${trimmedUser}@easynetbanking.com",
                    phone = "+91 9999999999"
                )
                
                authError.value = null
                currentUserId.value = trimmedUser
                isLoggedIn.value = true
                showPinScreen.value = false
                
                // Clear state for new user
                chatTranslations.value = emptyMap()
                _chatMessages.value = listOf(
                    LanguageTranslations.get("English", "copilot_welcome") to false
                )
                
                // Setup beautiful notifications queue for individual user
                setupDemoNotifications()
            }
        }
    }

    fun performSignup(username: String, pin: String, fullName: String, email: String, phone: String) {
        if (username.isBlank() || pin.isBlank() || fullName.isBlank()) {
            authError.value = "Username, PIN and Full Name are required"
            return
        }
        val trimmedUser = username.trim().lowercase()
        viewModelScope.launch {
            val existing = repository.getUserProfileOnce(trimmedUser)
            if (existing != null) {
                authError.value = "Username already exists!"
            } else {
                repository.populateDemoDataForUser(
                    userId = trimmedUser,
                    pinCode = pin,
                    fullName = fullName,
                    email = email,
                    phone = phone
                )
                authError.value = null
                activeAuthScreen.value = "LOGIN" // switch back to login screen
            }
        }
    }

    fun logout() {
        isLoggedIn.value = false
        currentUserId.value = ""
        currentTab.value = 0
        notifications.value = emptyList()
        activeAuthScreen.value = "LOGIN"
    }

    // --- Dynamic Notifications Queue ---
    private fun setupDemoNotifications() {
        notifications.value = listOf(
            NotificationItem(
                id = "notif_fraud_1",
                title = "🚨 Security Alert: Unrecognized Device",
                description = "We blocked a login attempt from Chrome on Linux (Kolkata). If this wasn't you, freeze card or change security PIN immediately.",
                type = "FRAUD",
                time = "Just now",
                priority = "HIGH"
            ),
            NotificationItem(
                id = "notif_budget_1",
                title = "📉 Overspending Alert on Dining",
                description = "Your spend on Swiggy (₹1,850) exceeded your weekly budget target of ₹1,000 by 85%. Start an Easy NetBanking saving plan to preserve excess cash.",
                type = "BUDGET",
                time = "2 hours ago",
                priority = "MEDIUM"
            ),
            NotificationItem(
                id = "notif_goal_1",
                title = "🏆 Gold Bond Goal Milestone",
                description = "Congratulations! Your 'Easy NetBanking Sovereign Gold Bond' saving goal has crossed 60% completion. You are only ₹60,000 away from your target.",
                type = "GOAL",
                time = "Yesterday",
                priority = "LOW"
            ),
            NotificationItem(
                id = "notif_offer_1",
                title = "✨ Specialized High-Yield SIP Opportunity",
                description = "Based on your active income streams, starting an Easy NetBanking Flexi SIP with ₹12,000/month could yield ₹15.6 Lakhs in 5 years. Tap to simulate.",
                type = "OFFER",
                time = "2 days ago",
                priority = "HIGH"
            )
        )
    }

    fun dismissNotification(id: String) {
        notifications.value = notifications.value.filter { it.id != id }
    }

    // --- Bhashini AI Translation Support ---
    fun translateMessageViaBhashini(messageIndex: Int, text: String, targetLanguage: String) {
        if (isTranslationLoading.value != null) return
        isTranslationLoading.value = messageIndex
        viewModelScope.launch {
            val translated = GeminiService.translateWithBhashini(text, targetLanguage)
            chatTranslations.value = chatTranslations.value + (messageIndex to translated)
            isTranslationLoading.value = null
        }
    }

    fun translateBhashiniCustomText() {
        val text = bhashiniSourceText.value
        val lang = bhashiniTargetLanguage.value
        if (text.isBlank()) return
        isBhashiniTranslating.value = true
        viewModelScope.launch {
            val result = GeminiService.translateWithBhashini(text, lang)
            bhashiniTranslatedText.value = result
            isBhashiniTranslating.value = false
        }
    }

    // --- Database Modification Actions ---
    fun addTransaction(title: String, amount: Double, type: String, category: String, notes: String = "") {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val tx = Transaction(
                userId = activeUser,
                title = title,
                amount = amount,
                type = type,
                category = category,
                timestamp = System.currentTimeMillis(),
                isSuspicious = category.lowercase().contains("unknown") || title.lowercase().contains("suspicious"),
                notes = notes
            )
            repository.insertTransaction(tx)
            
            // Adjust health score dynamically based on transaction types
            val profile = userProfile.value ?: UserProfile(id = activeUser)
            val scoreDiff = if (type == "EXPENSE" && amount > 20000) -4 else if (type == "INCOME") 2 else -1
            val newScore = (profile.healthScore + scoreDiff).coerceIn(0, 100)
            repository.updateProfile(profile.copy(healthScore = newScore))
        }
    }

    fun resolveSuspiciousTransaction(transaction: Transaction, isSafe: Boolean) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            if (isSafe) {
                // Mark as safe
                repository.updateTransaction(transaction.copy(isSuspicious = false))
                // Boost financial health score slightly for positive verification
                val profile = userProfile.value
                if (profile != null) {
                    val newScore = (profile.healthScore + 2).coerceIn(0, 100)
                    repository.updateProfile(profile.copy(healthScore = newScore))
                }
            } else {
                // Delete / block transaction
                repository.deleteTransaction(transaction)
                // Boost health score more for catching and blocking a fraud!
                val profile = userProfile.value
                if (profile != null) {
                    val newScore = (profile.healthScore + 5).coerceIn(0, 100)
                    repository.updateProfile(profile.copy(healthScore = newScore))
                }
            }
        }
    }

    fun updateGoal(goal: SavingGoal, current: Double) {
        viewModelScope.launch {
            repository.updateGoal(goal.copy(currentAmount = current))
        }
    }

    fun addGoal(name: String, target: Double, deadline: String) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            repository.insertGoal(SavingGoal(userId = activeUser, name = name, targetAmount = target, currentAmount = 0.0, deadline = deadline))
        }
    }

    fun updateChallengeProgress(challenge: FinancialChallenge, newProgress: Float) {
        viewModelScope.launch {
            val completed = newProgress >= 1.0f
            repository.updateChallenge(challenge.copy(progress = newProgress, isCompleted = completed))
        }
    }

    fun setLanguage(lang: String) {
        selectedLanguage.value = lang
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            repository.updateProfile(current.copy(language = lang))
            
            // Update initial chatbot welcome message when language changes
            _chatMessages.value = listOf(
                LanguageTranslations.get(lang, "copilot_welcome") to false
            )
        }
    }

    fun toggleTheme() {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val currentMode = if (isDarkMode.value) "LIGHT" else "DARK"
            isDarkMode.value = !isDarkMode.value
            val current = userProfile.value ?: UserProfile(id = activeUser)
            repository.updateProfile(current.copy(themeMode = currentMode))
        }
    }

    fun updateProfileMode(mode: String, enabled: Boolean) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            val updated = when(mode) {
                "STUDENT" -> current.copy(studentModeEnabled = enabled)
                "FARMER" -> current.copy(farmerModeEnabled = enabled)
                "BUSINESS" -> current.copy(businessModeEnabled = enabled)
                "SENIOR" -> current.copy(seniorCitizenModeEnabled = enabled)
                "FAMILY" -> current.copy(familyModeEnabled = enabled)
                else -> current
            }
            repository.updateProfile(updated)
        }
    }

    fun updatePinLockEnabled(enabled: Boolean) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            repository.updateProfile(current.copy(pinLockEnabled = enabled))
        }
    }

    fun updatePinCode(pin: String) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            repository.updateProfile(current.copy(pinCode = pin))
        }
    }

    fun updateBiometricsEnabled(enabled: Boolean) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            repository.updateProfile(current.copy(biometricsEnabled = enabled))
        }
    }

    suspend fun getUserProfileOnce(userId: String): UserProfile? {
        return repository.getUserProfileOnce(userId)
    }

    fun boostHealthScore(amount: Int) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            val newScore = (current.healthScore + amount).coerceIn(0, 100)
            repository.updateProfile(current.copy(healthScore = newScore))
        }
    }

    fun updateProfileDetails(fullName: String, email: String, phone: String) {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile(id = activeUser)
            repository.updateProfile(current.copy(fullName = fullName, email = email, phone = phone))
        }
    }

    fun clearAllTransactions() {
        val activeUser = currentUserId.value
        if (activeUser.isEmpty()) return
        viewModelScope.launch {
            repository.deleteAllTransactions(activeUser)
        }
    }

    // --- Advanced Chat Copilot Logic ---
    fun sendChatMessage(message: String) {
        if (message.isBlank()) return
        
        // Append user message
        _chatMessages.value = _chatMessages.value + (message to true)
        isChatLoading.value = true

        viewModelScope.launch {
            // Collect advanced context data (portfolio analysis, health analysis, modes)
            val contextInfo = getContextDataString()
            
            // Execute highly optimized advice flow with detailed cashflow forecasting instructions
            val aiResponse = withContext(Dispatchers.IO) {
                GeminiService.getFinancialAdvice(message, contextInfo)
            }
            
            _chatMessages.value = _chatMessages.value + (aiResponse to false)
            isChatLoading.value = false
            
            // Auto play voice response
            speak(stripMarkdown(aiResponse))
        }
    }

    private fun getContextDataString(): String {
        val txs = transactions.value.take(10).joinToString { 
            "${it.type}: ₹${it.amount} on ${it.category} (${it.title})" 
        }
        val gls = goals.value.joinToString { 
            "${it.name}: ₹${it.currentAmount}/₹${it.targetAmount}" 
        }
        val profile = userProfile.value
        return """
User Account: ${profile?.id ?: "Suhail"}
Full Name: ${profile?.fullName ?: "Suhail Rahman"}
Financial Consciousness Score: ${profile?.healthScore ?: 78}/100
Preferred Language: ${selectedLanguage.value}
Active Saving Goals: $gls
Farmer Special Mode: ${profile?.farmerModeEnabled ?: false}
Student Special Mode: ${profile?.studentModeEnabled ?: false}
Business Special Mode: ${profile?.businessModeEnabled ?: false}
Senior Citizen Benefit Mode: ${profile?.seniorCitizenModeEnabled ?: false}
Family Budget Protection Mode: ${profile?.familyModeEnabled ?: false}
Recent Transaction Registry (Isolated):
$txs
"""
    }

    // --- AI Call Assistant (Interactive Voice Dialog) ---
    fun startCall() {
        isCallActive.value = true
        callTranscript.value = listOf("Easy NetBanking AI: Connected. Hello! I am your AI Call Assistant. How can I help you today?" to false)
        speak("Connected. Hello! I am your Easy NetBanking AI Call Assistant. How can I help you today?")
    }

    fun endCall() {
        isCallActive.value = false
        stopSpeaking()
        callTranscript.value = emptyList()
    }

    fun handleVoiceCommand(spokenText: String) {
        if (spokenText.isBlank()) return
        callTranscript.value = callTranscript.value + (spokenText to true)
        isCallSpeaking.value = true

        viewModelScope.launch {
            val contextInfo = getContextDataString()
            val aiResponse = withContext(Dispatchers.IO) {
                GeminiService.getFinancialAdvice("Short voice command: $spokenText", contextInfo)
            }
            // Keep speech answers concise
            val conciseResponse = if (aiResponse.length > 250) {
                aiResponse.substring(0, 247) + "..."
            } else {
                aiResponse
            }
            callTranscript.value = callTranscript.value + (conciseResponse to false)
            isCallSpeaking.value = false
            speak(stripMarkdown(conciseResponse))
        }
    }

    // --- What-If Simulator Action ---
    fun runWhatIfSimulator() {
        val save = simSaveAmount.value.toDoubleOrNull() ?: 5000.0
        val reduce = simReduceFood.value.toDoubleOrNull() ?: 2000.0
        val loan = simLoanAmount.value.toDoubleOrNull() ?: 1000000.0

        isSimLoading.value = true
        viewModelScope.launch {
            val query = "Simulate and compare these financial decisions:\n" +
                    "1. What if I save additional ₹$save/month in an Easy NetBanking Tax Saving FD?\n" +
                    "2. What if I take an Easy NetBanking Home Loan of ₹$loan at 8.5% interest?\n" +
                    "3. What if I reduce food expenses by ₹$reduce/month?"
            
            val result = withContext(Dispatchers.IO) {
                GeminiService.getFinancialAdvice(query)
            }
            simResult.value = result
            isSimLoading.value = false
        }
    }

    // --- EMI Calculator Action ---
    fun calculateEmi() {
        val p = emiLoanAmount.value.toDoubleOrNull() ?: 1000000.0
        val r = (emiInterestRate.value.toDoubleOrNull() ?: 8.5) / 12 / 100
        val n = (emiTenureYears.value.toIntOrNull() ?: 15) * 12

        if (r == 0.0) {
            emiResult.value = "₹${String.format("%.2f", p / n)} / month"
            return
        }

        val emi = p * r * Math.pow(1 + r, n.toDouble()) / (Math.pow(1 + r, n.toDouble()) - 1)
        emiResult.value = "₹${String.format("%,.0f", emi)} / month"
    }

    // --- Helper to Strip Markdown for Clean Speech ---
    private fun stripMarkdown(input: String): String {
        return input.replace(Regex("[*#_`~]"), "")
    }

    override fun onCleared() {
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
