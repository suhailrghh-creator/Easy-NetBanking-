package com.example.ui.screen

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPilotViewModel
import com.example.data.api.LanguageTranslations
import com.example.ui.util.debounced
import com.example.ui.util.debouncedClickable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(viewModel: FinPilotViewModel) {
    val activeScreen by viewModel.activeAuthScreen.collectAsState()
    val language by viewModel.selectedLanguage.collectAsState()
    var showLanguageDialog by remember { mutableStateOf(false) }

    val bgGradient = Brush.verticalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.background,
            SbiBlue.copy(alpha = 0.15f),
            MaterialTheme.colorScheme.background
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgGradient)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Language Select Button in Top-Right of outer Box
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            IconButton(
                onClick = { showLanguageDialog = true },
                modifier = Modifier
                    .background(SbiLightBlue.copy(alpha = 0.1f), CircleShape)
                    .size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Translate,
                    contentDescription = "Change Language",
                    tint = SbiLightBlue
                )
            }
        }

        if (showLanguageDialog) {
            AlertDialog(
                onDismissRequest = { showLanguageDialog = false },
                title = { Text(LanguageTranslations.get(language, "select_lang_title")) },
                confirmButton = {
                    TextButton(onClick = { showLanguageDialog = false }) {
                        Text("Close")
                    }
                },
                text = {
                    LazyColumn(
                        modifier = Modifier.height(260.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(listOf("English", "Hindi", "Tamil", "Telugu")) { lang ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (language == lang) SbiLightBlue.copy(alpha = 0.12f) else Color.Transparent)
                                    .clickable {
                                        viewModel.setLanguage(lang)
                                        showLanguageDialog = false
                                    }
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(lang, fontWeight = if (language == lang) FontWeight.Bold else FontWeight.Normal)
                                    if (language == lang) {
                                        Icon(Icons.Filled.Check, "Selected", tint = SbiLightBlue)
                                    }
                                }
                            }
                        }
                    }
                }
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // App Header
            Icon(
                imageVector = Icons.Filled.AccountBalance,
                contentDescription = "Easy NetBanking Logo",
                tint = SbiLightBlue,
                modifier = Modifier
                    .size(64.dp)
                    .background(SbiBlue.copy(alpha = 0.1f), CircleShape)
                    .padding(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = LanguageTranslations.get(language, "app_title"),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = SbiLightBlue,
                textAlign = TextAlign.Center
            )

            Text(
                text = LanguageTranslations.get(language, "tagline"),
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Auth card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(24.dp)
            ) {
                AnimatedContent(
                    targetState = activeScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "AuthFormAnimation"
                ) { screen ->
                    when (screen) {
                        "LOGIN" -> LoginForm(viewModel)
                        "SIGNUP" -> SignupForm(viewModel)
                        "FORGOT" -> ForgotPasswordForm(viewModel)
                        "OTP" -> OtpLoginForm(viewModel)
                        "PIN_UNLOCK" -> PinUnlockForm(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun LoginForm(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val authError by viewModel.authError.collectAsState()
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var showBiometricScan by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column {
        Text(
            text = LanguageTranslations.get(language, "login"),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (authError != null) {
            Text(
                text = authError!!,
                color = Color.Red,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        OutlinedTextField(
            value = username,
            onValueChange = { 
                username = it
                viewModel.authError.value = null
            },
            label = { Text(LanguageTranslations.get(language, "username")) },
            leadingIcon = { Icon(Icons.Filled.Person, "User") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("username_input")
                .padding(bottom = 12.dp),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = password,
            onValueChange = { 
                password = it
                viewModel.authError.value = null
            },
            label = { Text("4-digit Security PIN") },
            leadingIcon = { Icon(Icons.Filled.Lock, "Lock") },
            trailingIcon = {
                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                    Icon(
                        imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = "Toggle password visibility"
                    )
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = LanguageTranslations.get(language, "otp_sign_in"),
                color = SbiLightBlue,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.debouncedClickable {
                    viewModel.activeAuthScreen.value = "OTP"
                }
            )

            Text(
                text = LanguageTranslations.get(language, "forgot_pwd"),
                color = SbiLightBlue,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.debouncedClickable {
                    viewModel.activeAuthScreen.value = "FORGOT"
                }
            )
        }

        Button(
            onClick = debounced { viewModel.performLogin(username, password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("login_button"),
            colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(LanguageTranslations.get(language, "login"), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Biometrics (Real-time dynamic check)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SbiLightBlue.copy(alpha = 0.12f))
                .debouncedClickable {
                    val lastUser = viewModel.getLastLoggedInUser()
                    if (lastUser.isEmpty()) {
                        viewModel.authError.value = "No previous user found on this device. Please log in with PIN first."
                        return@debouncedClickable
                    }
                    showBiometricScan = true
                    scope.launch {
                        delay(1500)
                        viewModel.performBiometricLogin { success, message ->
                            showBiometricScan = false
                            if (!success) {
                                viewModel.authError.value = message
                            }
                        }
                    }
                }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Filled.Fingerprint, "Biometric", tint = SbiLightBlue)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                LanguageTranslations.get(language, "biometric_login"),
                color = SbiLightBlue,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "New to Easy NetBanking? Sign Up",
                fontSize = 13.sp,
                color = SbiLightBlue,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.debouncedClickable {
                    viewModel.authError.value = null
                    viewModel.activeAuthScreen.value = "SIGNUP"
                }
            )
        }
    }

    if (showBiometricScan) {
        AlertDialog(
            onDismissRequest = { showBiometricScan = false },
            confirmButton = {},
            title = {
                Text(
                    "Face ID / Touch ID",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Face,
                        contentDescription = "Scanning",
                        tint = SbiLightBlue,
                        modifier = Modifier
                            .size(72.dp)
                            .padding(bottom = 12.dp)
                    )
                    Text("Scanning face for biometric security authorization...")
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(color = SbiLightBlue, modifier = Modifier.fillMaxWidth())
                }
            }
        )
    }
}

@Composable
fun SignupForm(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val authError by viewModel.authError.collectAsState()
    var username by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pinCode by remember { mutableStateOf("") }

    Column {
        Text(
            text = LanguageTranslations.get(language, "signup"),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (authError != null) {
            Text(
                text = authError!!,
                color = Color.Red,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Choose Username") },
            leadingIcon = { Icon(Icons.Filled.PersonOutline, "Username") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Name") },
            leadingIcon = { Icon(Icons.Filled.Person, "Name") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            leadingIcon = { Icon(Icons.Filled.Email, "Email") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Phone Number") },
            leadingIcon = { Icon(Icons.Filled.Phone, "Phone") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = pinCode,
            onValueChange = { pinCode = it },
            label = { Text("Choose 4-digit Security PIN") },
            leadingIcon = { Icon(Icons.Filled.Lock, "PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(12.dp)
        )

        Button(
            onClick = debounced { 
                viewModel.performSignup(
                    username = username,
                    pin = pinCode,
                    fullName = fullName,
                    email = email,
                    phone = phone
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Create Account", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Already have an account? Login",
                fontSize = 13.sp,
                color = SbiLightBlue,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.debouncedClickable {
                    viewModel.authError.value = null
                    viewModel.activeAuthScreen.value = "LOGIN"
                }
            )
        }
    }
}

@Composable
fun ForgotPasswordForm(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    var email by remember { mutableStateOf("") }
    var linkSent by remember { mutableStateOf(false) }

    Column {
        Text(
            text = LanguageTranslations.get(language, "forgot_pwd"),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (!linkSent) {
            Text(
                "Enter your email to receive a secure recovery verification link.",
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 16.dp),
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address") },
                leadingIcon = { Icon(Icons.Filled.Email, "Email") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = debounced { linkSent = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Send Reset Link", fontWeight = FontWeight.Bold)
            }
        } else {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = "Success",
                tint = SbiSuccess,
                modifier = Modifier
                    .size(64.dp)
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 12.dp)
            )
            Text(
                "A secure reset token has been dispatched successfully! Please check your mailbox.",
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 16.dp),
                color = SbiSuccess
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Back to Login",
                fontSize = 13.sp,
                color = SbiLightBlue,
                modifier = Modifier.debouncedClickable {
                    viewModel.activeAuthScreen.value = "LOGIN"
                }
            )
        }
    }
}

@Composable
fun OtpLoginForm(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    var mobile by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var codeSent by remember { mutableStateOf(false) }

    Column {
        Text(
            text = LanguageTranslations.get(language, "otp_sign_in"),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (!codeSent) {
            OutlinedTextField(
                value = mobile,
                onValueChange = { mobile = it },
                label = { Text("Mobile Number (+91)") },
                leadingIcon = { Icon(Icons.Filled.Phone, "Phone") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = debounced { codeSent = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Send OTP", fontWeight = FontWeight.Bold)
            }
        } else {
            Text(
                LanguageTranslations.get(language, "otp_sent"),
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 16.dp),
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )

            OutlinedTextField(
                value = code,
                onValueChange = { code = it },
                label = { Text("Enter OTP Code") },
                leadingIcon = { Icon(Icons.Filled.LockOpen, "OTP") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = debounced { viewModel.performLogin("Suhail Rahman", "OTP_$code") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(LanguageTranslations.get(language, "otp_verify"), fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Back to Login",
                fontSize = 13.sp,
                color = SbiLightBlue,
                modifier = Modifier.debouncedClickable {
                    viewModel.activeAuthScreen.value = "LOGIN"
                }
            )
        }
    }
}

@Composable
fun PinUnlockForm(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val scope = rememberCoroutineScope()
    var pinCode by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var showBiometricScan by remember { mutableStateOf(false) }
    
    val lastUser = viewModel.getLastLoggedInUser()
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var biometricsEnabled by remember { mutableStateOf(false) }

    LaunchedEffect(lastUser) {
        if (lastUser.isNotEmpty()) {
            val profile = viewModel.getUserProfileOnce(lastUser)
            if (profile != null) {
                fullName = profile.fullName
                email = profile.email
                biometricsEnabled = profile.biometricsEnabled
                
                // If biometrics is enabled, automatically trigger face/fingerprint biometric scanning dialog!
                if (biometricsEnabled) {
                    showBiometricScan = true
                    delay(1500)
                    viewModel.performBiometricLogin { success, message ->
                        showBiometricScan = false
                        if (!success) {
                            viewModel.authError.value = message
                        }
                    }
                }
            }
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "Welcome Back",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // User Avatar and Info Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SbiLightBlue.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Person,
                contentDescription = "User Avatar",
                tint = SbiLightBlue,
                modifier = Modifier
                    .size(48.dp)
                    .background(SbiLightBlue.copy(alpha = 0.15f), CircleShape)
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(fullName.ifEmpty { lastUser }, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(email.ifEmpty { "Registered User" }, fontSize = 11.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (authError != null) {
            Text(
                text = authError!!,
                color = Color.Red,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // PIN text field
        OutlinedTextField(
            value = pinCode,
            onValueChange = { 
                pinCode = it
                viewModel.authError.value = null
                if (it.length == 4) {
                    viewModel.performLogin(lastUser, it)
                }
            },
            label = { Text("4-digit Security PIN") },
            leadingIcon = { Icon(Icons.Filled.Lock, "Lock") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Click to scan biometrics manually if enabled
            if (biometricsEnabled) {
                Row(
                    modifier = Modifier
                        .background(SbiLightBlue.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                        .clickable {
                            showBiometricScan = true
                            scope.launch {
                                delay(1500)
                                viewModel.performBiometricLogin { success, message ->
                                    showBiometricScan = false
                                    if (!success) {
                                        viewModel.authError.value = message
                                    }
                                }
                            }
                        }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Fingerprint, "Biometric", tint = SbiLightBlue, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tap to Scan", color = SbiLightBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            } else {
                Spacer(modifier = Modifier.width(1.dp))
            }

            // Switch back to Login Form
            Text(
                text = "Switch Account",
                color = SbiLightBlue,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable {
                        viewModel.activeAuthScreen.value = "LOGIN"
                    }
                    .padding(8.dp)
            )
        }

        // Biometric scanning dialog inside PIN Unlock Form
        if (showBiometricScan) {
            AlertDialog(
                onDismissRequest = { showBiometricScan = false },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showBiometricScan = false }) {
                        Text("Cancel")
                    }
                },
                title = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Fingerprint,
                            contentDescription = "Scan icon",
                            tint = SbiLightBlue,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Biometric Verification",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                },
                text = {
                    Text(
                        "Scanning face/fingerprint for secure biometric authorization...",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            )
        }
    }
}
