package com.example.ui.screen

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPilotViewModel
import com.example.data.api.LanguageTranslations
import com.example.ui.util.debounced
import com.example.ui.util.debouncedClickable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MainScreen(viewModel: FinPilotViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val isCallActive by viewModel.isCallActive.collectAsState()
    val language by viewModel.selectedLanguage.collectAsState()
    val context = LocalContext.current

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                viewModel.startCall()
                viewModel.startListening(context)
            } else {
                Toast.makeText(context, "Microphone permission is required for AI Voice Call.", Toast.LENGTH_LONG).show()
            }
        }
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                        RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = debounced { viewModel.currentTab.value = 0 },
                    icon = { Icon(Icons.Filled.AccountBalance, contentDescription = "Dashboard") },
                    label = { Text(LanguageTranslations.get(language, "dashboard"), fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = SbiLightBlue,
                        indicatorColor = SbiLightBlue
                    )
                )

                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = debounced { viewModel.currentTab.value = 1 },
                    icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = "Copilot") },
                    label = { Text(LanguageTranslations.get(language, "ai_copilot"), fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = SbiLightBlue,
                        indicatorColor = SbiLightBlue
                    )
                )

                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = debounced { viewModel.currentTab.value = 2 },
                    icon = { Icon(Icons.Filled.Psychology, contentDescription = "Tools") },
                    label = { Text(LanguageTranslations.get(language, "challenges"), fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = SbiLightBlue,
                        indicatorColor = SbiLightBlue
                    )
                )

                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = debounced { viewModel.currentTab.value = 3 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                    label = { Text(LanguageTranslations.get(language, "settings"), fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = SbiLightBlue,
                        indicatorColor = SbiLightBlue
                    )
                )
            }
        },
        floatingActionButton = {
            // Floating Microphone Button
            FloatingActionButton(
                onClick = debounced {
                    val permissionCheck = androidx.core.content.ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.RECORD_AUDIO
                    )
                    if (permissionCheck == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        viewModel.startCall()
                        viewModel.startListening(context)
                    } else {
                        micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    }
                },
                containerColor = SbiLightBlue,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 72.dp)
                    .size(56.dp)
            ) {
                Icon(Icons.Filled.Mic, "AI Call Assistant", modifier = Modifier.size(28.dp))
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> DashboardScreen(viewModel)
                1 -> AiCopilotScreen(viewModel)
                2 -> ChallengesScreen(viewModel)
                3 -> SettingsScreen(viewModel)
            }

            // Call overlay if active
            AnimatedVisibility(
                visible = isCallActive,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                CallAssistantOverlay(viewModel)
            }
        }
    }
}

@Composable
fun CallAssistantOverlay(viewModel: FinPilotViewModel) {
    val transcript by viewModel.callTranscript.collectAsState()
    val isSpeaking by viewModel.isCallSpeaking.collectAsState()
    var simulatedSpokenText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val suggestedCommands = listOf(
        "How much did I spend this month?",
        "Can I take a home loan?",
        "What EMI can I afford?"
    )

    // Wave ripples animation effect
    var waveScale1 by remember { mutableStateOf(1f) }
    var waveScale2 by remember { mutableStateOf(1.2f) }
    val isListening by viewModel.isListening.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(isSpeaking, isListening) {
        if (isSpeaking || isListening) {
            while (isSpeaking || isListening) {
                waveScale1 = 1.3f
                waveScale2 = 1.6f
                delay(600)
                waveScale1 = 1f
                waveScale2 = 1.2f
                delay(600)
            }
        } else {
            waveScale1 = 1f
            waveScale2 = 1.1f
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SbiDarkBg)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Upper active info tag
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isListening) SbiGold else Color.Red)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isListening) "Easy NetBanking AI: Listening..." else if (isSpeaking) "Easy NetBanking AI: Speaking..." else "Easy NetBanking AI: Connected",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.endCall() },
                    modifier = Modifier
                        .background(Color.Red, CircleShape)
                        .size(36.dp)
                ) {
                    Icon(Icons.Filled.CallEnd, "End Call", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }

            // Transcript conversation log
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(transcript) { itemPair ->
                        val (msg, isUser) = itemPair
                        Text(
                            text = if (isUser) "You: $msg" else "Easy NetBanking: $msg",
                            color = if (isUser) SbiLightBlue else Color.White,
                            fontSize = 13.sp,
                            fontWeight = if (isUser) FontWeight.Medium else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Central Wave Visualizer
            Box(
                modifier = Modifier
                    .size(180.dp),
                contentAlignment = Alignment.Center
            ) {
                // Interactive ripple wave shapes
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .border(
                            width = (waveScale1 * 2).dp,
                            color = SbiLightBlue.copy(alpha = 0.3f),
                            shape = CircleShape
                        )
                )
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .border(
                            width = (waveScale2 * 2).dp,
                            color = SbiLightBlue.copy(alpha = 0.15f),
                            shape = CircleShape
                        )
                )

                // Main Central microphone circle
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(if (isListening) SbiGold else SbiLightBlue)
                        .border(2.dp, SbiGold, CircleShape)
                        .clickable {
                            val permissionCheck = androidx.core.content.ContextCompat.checkSelfPermission(
                                context,
                                android.Manifest.permission.RECORD_AUDIO
                            )
                            if (permissionCheck == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                viewModel.toggleSpeechListening(context)
                            } else {
                                Toast.makeText(context, "Microphone permission not granted. Please restart call.", Toast.LENGTH_LONG).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Filled.RecordVoiceOver else Icons.Filled.Mic,
                        contentDescription = "Active call indicator",
                        tint = Color.White,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            // Dynamic interactive presets
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isListening) "Listening... Speak now!" else "Tap the microphone to speak, or select a quick option below:",
                    color = if (isListening) SbiGold else Color.LightGray,
                    fontWeight = if (isListening) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    suggestedCommands.forEach { cmd ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.08f))
                                .clickable {
                                    viewModel.handleVoiceCommand(cmd)
                                }
                                .padding(horizontal = 8.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cmd,
                                color = Color.White,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Custom audio input typing mock box for full accessibility
                OutlinedTextField(
                    value = simulatedSpokenText,
                    onValueChange = { simulatedSpokenText = it },
                    placeholder = { Text("Speak or type custom voice query...", color = Color.Gray) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SbiLightBlue,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (simulatedSpokenText.isNotBlank()) {
                                    viewModel.handleVoiceCommand(simulatedSpokenText)
                                    simulatedSpokenText = ""
                                }
                            }
                        ) {
                            Icon(Icons.Filled.Send, "Send Voice", tint = SbiLightBlue)
                        }
                    }
                )
            }
        }
    }
}
