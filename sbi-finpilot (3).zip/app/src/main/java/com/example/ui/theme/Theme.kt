package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SbiLightBlue,
    secondary = SbiBlue,
    tertiary = SbiGold,
    background = SbiDarkBg,
    surface = SbiDarkSurface,
    onPrimary = SbiDarkBg,
    onSecondary = SbiOnDarkText,
    onTertiary = SbiDarkBg,
    onBackground = SbiOnDarkText,
    onSurface = SbiOnDarkText,
    error = SbiError
)

private val LightColorScheme = lightColorScheme(
    primary = SbiBlue,
    secondary = SbiLightBlue,
    tertiary = SbiGold,
    background = SbiLightBg,
    surface = SbiLightSurface,
    onPrimary = SbiLightSurface,
    onSecondary = SbiOnLightText,
    onTertiary = SbiOnLightText,
    onBackground = SbiOnLightText,
    onSurface = SbiOnLightText,
    error = SbiError
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We choose not to enforce dynamic colors on Android 12+ so that the Easy NetBanking FinPilot
    // premium custom blue brand colors remain dominant and strictly unified.
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
