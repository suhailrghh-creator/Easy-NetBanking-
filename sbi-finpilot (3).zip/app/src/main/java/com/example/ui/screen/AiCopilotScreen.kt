package com.example.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPilotViewModel
import com.example.data.api.LanguageTranslations
import com.example.ui.util.debounced
import com.example.ui.util.debouncedClickable
import kotlinx.coroutines.launch

@Composable
fun AiCopilotScreen(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()
    val isVoiceEnabled by viewModel.isVoiceEnabled.collectAsState()

    // Bhashini dedicated states
    val bhashiniSource by viewModel.bhashiniSourceText.collectAsState()
    val bhashiniTarget by viewModel.bhashiniTargetLanguage.collectAsState()
    val bhashiniResult by viewModel.bhashiniTranslatedText.collectAsState()
    val isBhashiniTranslating by viewModel.isBhashiniTranslating.collectAsState()

    var inputMessage by remember { mutableStateOf("") }
    var showBhashiniDesk by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Auto-scroll to latest message
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            scope.launch {
                listState.animateScrollToItem(chatMessages.size - 1)
            }
        }
    }

    val presetQueries = listOf(
        "Predict next month cashflow",
        "Explain compound interest simply",
        "Generate monthly Easy NetBanking financial report",
        "Recommend suitable Easy NetBanking investments"
    )

    val indianLanguages = listOf(
        "Hindi", "Tamil", "Telugu", "Kannada", "Malayalam", 
        "Bengali", "Gujarati", "Marathi", "Odia", "Punjabi"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Upper Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "Copilot",
                    tint = SbiGold,
                    modifier = Modifier
                        .size(36.dp)
                        .background(SbiGold.copy(alpha = 0.1f), CircleShape)
                        .padding(8.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Easy NetBanking AI",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Bhashini Translation Protocol Active",
                        fontSize = 11.sp,
                        color = SbiLightBlue,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Collapsible Bhashini Custom Translator Button
                IconButton(
                    onClick = { showBhashiniDesk = !showBhashiniDesk },
                    modifier = Modifier
                        .background(
                            if (showBhashiniDesk) SbiGold.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.1f),
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Translate,
                        contentDescription = "Bhashini Desk",
                        tint = if (showBhashiniDesk) SbiGold else MaterialTheme.colorScheme.onSurface
                    )
                }

                // Voice feedback toggle
                IconButton(
                    onClick = debounced { viewModel.isVoiceEnabled.value = !isVoiceEnabled },
                    modifier = Modifier
                        .background(
                            if (isVoiceEnabled) SbiLightBlue.copy(alpha = 0.1f) else Color.Gray.copy(alpha = 0.1f),
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = if (isVoiceEnabled) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                        contentDescription = "TTS toggle",
                        tint = if (isVoiceEnabled) SbiLightBlue else Color.Gray
                    )
                }
            }
        }

        // Bhashini Dedicated Translation Desk
        if (showBhashiniDesk) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, SbiGold.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "Bhashini Multi-Lingual Translation Desk",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = SbiGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedTextField(
                        value = bhashiniSource,
                        onValueChange = { viewModel.bhashiniSourceText.value = it },
                        placeholder = { Text("Enter financial phrase or query...", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SbiGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        var expandedLang by remember { mutableStateOf(false) }
                        
                        Box {
                            Button(
                                onClick = { expandedLang = true },
                                colors = ButtonDefaults.buttonColors(containerColor = SbiBlue.copy(alpha = 0.15f), contentColor = SbiLightBlue),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("To: $bhashiniTarget", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Icon(Icons.Filled.ArrowDropDown, "down", modifier = Modifier.size(16.dp))
                            }
                            DropdownMenu(expanded = expandedLang, onDismissRequest = { expandedLang = false }) {
                                indianLanguages.forEach { lang ->
                                    DropdownMenuItem(
                                        text = { Text(lang, fontSize = 12.sp) },
                                        onClick = {
                                            viewModel.bhashiniTargetLanguage.value = lang
                                            expandedLang = false
                                        }
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { viewModel.translateBhashiniCustomText() },
                            colors = ButtonDefaults.buttonColors(containerColor = SbiGold),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            enabled = !isBhashiniTranslating
                        ) {
                            if (isBhashiniTranslating) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.AutoAwesome, "Translate", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Bhashini Translate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (bhashiniResult.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SbiGold.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                .border(0.5.dp, SbiGold.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(bhashiniResult, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp)
                        }
                    }
                }
            }
        }

        // Chat Conversation Box
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(chatMessages) { index, messagePair ->
                val (text, isUser) = messagePair
                ChatBubble(index = index, text = text, isUser = isUser, viewModel = viewModel)
            }

            if (isChatLoading) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = SbiLightBlue,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Easy NetBanking is formulating advanced financial model analysis...",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        // Preset query suggestions (shown if no extensive logs)
        if (chatMessages.size <= 1) {
            Text(
                "Recommended Queries for Easy NetBanking Advisor",
                fontSize = 12.sp,
                color = SbiLightBlue,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
            )
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
            ) {
                items(presetQueries) { query ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .debouncedClickable {
                                inputMessage = query
                                viewModel.sendChatMessage(query)
                                inputMessage = ""
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.FlashOn, "Quick", tint = SbiGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(query, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat Input box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 90.dp), // Safe zone for bottom nav
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputMessage,
                onValueChange = { inputMessage = it },
                placeholder = { Text("Ask Easy NetBanking anything...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input"),
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (inputMessage.isNotBlank()) {
                        viewModel.sendChatMessage(inputMessage)
                        inputMessage = ""
                        keyboardController?.hide()
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SbiLightBlue,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                )
            )

            IconButton(
                onClick = {
                    if (inputMessage.isNotBlank()) {
                        viewModel.sendChatMessage(inputMessage)
                        inputMessage = ""
                        keyboardController?.hide()
                    }
                },
                modifier = Modifier
                    .background(SbiLightBlue, CircleShape)
                    .size(48.dp)
            ) {
                Icon(Icons.Filled.Send, "Send", tint = Color.White)
            }
        }
    }
}

@Composable
fun ChatBubble(index: Int, text: String, isUser: Boolean, viewModel: FinPilotViewModel) {
    val translations by viewModel.chatTranslations.collectAsState()
    val translatingIndex by viewModel.isTranslationLoading.collectAsState()

    val indianLanguages = listOf(
        "Hindi", "Tamil", "Telugu", "Kannada", "Malayalam", 
        "Bengali", "Gujarati", "Marathi", "Odia", "Punjabi"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            if (!isUser) {
                Icon(
                    imageVector = Icons.Filled.AccountBalance,
                    contentDescription = "Bot",
                    tint = SbiLightBlue,
                    modifier = Modifier
                        .size(28.dp)
                        .background(SbiBlue.copy(alpha = 0.1f), CircleShape)
                        .padding(6.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Column(modifier = Modifier.weight(1f, fill = false)) {
                Box(
                    modifier = Modifier
                        .clip(
                            RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 16.dp
                            )
                        )
                        .background(
                            if (isUser) SbiLightBlue else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                        )
                        .border(
                            width = 1.dp,
                            color = if (isUser) Color.Transparent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 16.dp
                            )
                        )
                        .padding(14.dp)
                ) {
                    Text(
                        text = text,
                        fontSize = 13.sp,
                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                }

                // AI translation tools directly under bot message bubbles using Bhashini
                if (!isUser) {
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    var showLangPicker by remember { mutableStateOf(false) }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = { showLangPicker = !showLangPicker },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = "Bhashini Translate message",
                                tint = SbiGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Text(
                            text = "Bhashini Translation",
                            fontSize = 11.sp,
                            color = SbiGold,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable { showLangPicker = !showLangPicker }
                        )

                        if (translatingIndex == index) {
                            CircularProgressIndicator(
                                color = SbiGold,
                                modifier = Modifier.size(12.dp),
                                strokeWidth = 1.5.dp
                            )
                        }
                    }

                    if (showLangPicker) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            var expandedDropdown by remember { mutableStateOf(false) }
                            Box {
                                Button(
                                    onClick = { expandedDropdown = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = SbiLightBlue),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.border(0.5.dp, SbiLightBlue, RoundedCornerShape(8.dp))
                                ) {
                                    Text("Select Language", fontSize = 11.sp)
                                    Icon(Icons.Filled.ArrowDropDown, "drop", modifier = Modifier.size(14.dp))
                                }
                                DropdownMenu(expanded = expandedDropdown, onDismissRequest = { expandedDropdown = false }) {
                                    indianLanguages.forEach { lang ->
                                        DropdownMenuItem(
                                            text = { Text(lang, fontSize = 11.sp) },
                                            onClick = {
                                                viewModel.translateMessageViaBhashini(index, text, lang)
                                                expandedDropdown = false
                                                showLangPicker = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Display the translated Bhashini block
                    if (translations[index] != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, SbiGold.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(
                                containerColor = SbiGold.copy(alpha = 0.08f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.AutoAwesome, "Bhashini", tint = SbiGold, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Bhashini Translated Text:", fontSize = 11.sp, color = SbiGold, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = translations[index]!!,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            if (isUser) {
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = "User",
                    tint = Color.White,
                    modifier = Modifier
                        .size(28.dp)
                        .background(SbiLightBlue, CircleShape)
                        .padding(6.dp)
                )
            }
        }
    }
}
