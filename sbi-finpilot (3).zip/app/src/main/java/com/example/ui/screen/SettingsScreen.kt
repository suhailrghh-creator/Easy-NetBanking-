package com.example.ui.screen

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPilotViewModel
import com.example.data.api.LanguageTranslations
import com.example.ui.util.debounced
import com.example.ui.util.debouncedClickable
import com.example.data.model.UserProfile
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val isVoiceEnabled by viewModel.isVoiceEnabled.collectAsState()
    val profile by viewModel.userProfile.collectAsState()

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var reportDownloaded by remember { mutableStateOf(false) }
    var showSetPinDialog by remember { mutableStateOf(false) }
    var showRegisterBiometricsDialog by remember { mutableStateOf(false) }
    var isRegisteringBiometrics by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Upper Header
        item {
            Text(
                text = "Easy NetBanking VIP Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Manage your global Easy NetBanking preferences, voice modules, and security parameters.",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        // Profile Avatar Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(SbiLightBlue)
                                .border(2.dp, SbiGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Profile",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                profile?.fullName ?: "Suhail Rahman",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                profile?.email ?: "suhailrghh@gmail.com",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    IconButton(
                        onClick = { showEditProfileDialog = true },
                        modifier = Modifier
                            .background(SbiLightBlue.copy(alpha = 0.1f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(Icons.Filled.Edit, "Edit Profile", tint = SbiLightBlue, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Preferences Group
        item {
            Text(LanguageTranslations.get(language, "general_pref"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SbiLightBlue)
        }

        item {
            PreferenceRowToggle(
                title = LanguageTranslations.get(language, "dark_theme_ui"),
                subtitle = LanguageTranslations.get(language, "dark_theme_desc"),
                icon = Icons.Filled.DarkMode,
                checked = isDarkMode,
                onCheckedChange = { viewModel.toggleTheme() }
            )
        }

        item {
            PreferenceRowToggle(
                title = LanguageTranslations.get(language, "voice_assistant"),
                subtitle = LanguageTranslations.get(language, "voice_assistant_desc"),
                icon = Icons.Filled.VolumeUp,
                checked = isVoiceEnabled,
                onCheckedChange = { viewModel.isVoiceEnabled.value = it }
            )
        }

        item {
            PreferenceRowClickable(
                title = LanguageTranslations.get(language, "language"),
                subtitle = "Current: $language",
                icon = Icons.Filled.Translate,
                onClick = { showLanguageDialog = true }
            )
        }

        // Security & Reports Group
        item {
            Text(LanguageTranslations.get(language, "security_reports"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SbiLightBlue)
        }

        item {
            val pinEnabled = profile?.pinLockEnabled ?: false
            PreferenceRowToggle(
                title = LanguageTranslations.get(language, "require_pin"),
                subtitle = LanguageTranslations.get(language, "require_pin_desc"),
                icon = Icons.Filled.Lock,
                checked = pinEnabled,
                onCheckedChange = { enabled ->
                    if (enabled) {
                        showSetPinDialog = true
                    } else {
                        viewModel.updatePinLockEnabled(false)
                    }
                }
            )
        }

        item {
            val bioEnabled = profile?.biometricsEnabled ?: false
            PreferenceRowToggle(
                title = LanguageTranslations.get(language, "biometric_login"),
                subtitle = LanguageTranslations.get(language, "biometric_login_desc"),
                icon = Icons.Filled.Fingerprint,
                checked = bioEnabled,
                onCheckedChange = { enabled ->
                    if (enabled) {
                        showRegisterBiometricsDialog = true
                        isRegisteringBiometrics = true
                        scope.launch {
                            delay(1800) // Simulate a real biometric scan registration
                            isRegisteringBiometrics = false
                        }
                    } else {
                        viewModel.updateBiometricsEnabled(false)
                    }
                }
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        reportDownloaded = true
                        scope.launch {
                            delay(3000)
                            reportDownloaded = false
                        }
                    },
                colors = CardDefaults.cardColors(
                    containerColor = SbiLightBlue.copy(alpha = 0.08f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Download,
                        contentDescription = "Report",
                        tint = SbiLightBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (reportDownloaded) "PDF Report Dispatched!" else "Download Monthly Financial Report (PDF)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (reportDownloaded) SbiSuccess else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (reportDownloaded) "Check your downloads folder." else "Compile full transactional insights and forecasts.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        // System Architecture Group
        item {
            Text("System Architecture Details", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SbiLightBlue)
        }

        item {
            TechStackItem(
                title = "Frontend Experience",
                details = "React.js with TypeScript for type-safe state handling; styled with Tailwind CSS and intuitive symbolic iconography optimized for lower-literacy accessibility.",
                icon = Icons.Filled.Code,
                iconColor = SbiLightBlue
            )
        }

        item {
            TechStackItem(
                title = "Backend Service",
                details = "Node.js with Express.js establishing a lightweight, high-throughput REST API layer for async session management.",
                icon = Icons.Filled.Dns,
                iconColor = SbiGold
            )
        }

        item {
            TechStackItem(
                title = "AI Core & Orchestration",
                details = "Google Gemini 2.5 Flash API executing Agentic AI workflows, using native Function Calling and structured JSON outputs to run autonomous analytical loops (Understand → Collect → Analyze → Plan).",
                icon = Icons.Filled.Bolt,
                iconColor = SbiSuccess
            )
        }

        item {
            TechStackItem(
                title = "Public Digital Infrastructure Rails",
                details = "India’s Account Aggregator (AA) Sandbox APIs for zero-typing banking ledgers; Digital India's Banking BHASHINI APIs for real-time multilingual Speech-to-Text/Text-to-Speech; and the NPCI UPI Plug-in SDK for native, secure in-app transaction execution.",
                icon = Icons.Filled.AccountBalance,
                iconColor = SbiLightBlue
            )
        }

        item {
            TechStackItem(
                title = "Database & Security",
                details = "Firebase Firestore for real-time document storage (goals, user metrics, ledger vectors); Firebase Auth with JWT to enforce strict data isolation and absolute privacy in compliance with the DPDP Act.",
                icon = Icons.Filled.Shield,
                iconColor = SbiError
            )
        }

        // Session Actions Group
        item {
            Text("Session Control", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SbiLightBlue)
        }

        item {
            PreferenceRowClickable(
                title = "Logout from Session",
                subtitle = "Safely close this copilot session",
                icon = Icons.Filled.ExitToApp,
                onClick = { viewModel.logout() }
            )
        }

        item {
            PreferenceRowClickable(
                title = "Delete Active Account",
                subtitle = "Irreversibly wipe all local SQLite data",
                icon = Icons.Filled.DeleteForever,
                onClick = {
                    viewModel.clearAllTransactions()
                    viewModel.logout()
                }
            )
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        var editName by remember { mutableStateOf(profile?.fullName ?: "Suhail Rahman") }
        var editEmail by remember { mutableStateOf(profile?.email ?: "suhailrghh@gmail.com") }
        var editPhone by remember { mutableStateOf(profile?.phone ?: "+91 9876543210") }

        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Details") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateProfileDetails(editName, editEmail, editPhone)
                        showEditProfileDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editEmail,
                        onValueChange = { editEmail = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("Phone Number") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        )
    }

    // Language Selector Dialog
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text(LanguageTranslations.get(language, "language")) },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text("Close")
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier.height(260.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(LanguageTranslations.supportedLanguages) { lang ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (language == lang) SbiLightBlue.copy(alpha = 0.12f) else Color.Transparent)
                                .clickable {
                                    viewModel.setLanguage(lang)
                                    showLanguageDialog = false
                                }
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                  Text(lang, fontWeight = if (language == lang) FontWeight.Bold else FontWeight.Normal)
                                  if (language == lang) {
                                      Icon(Icons.Filled.Check, "Selected", tint = SbiLightBlue)
                                  }
                            }
                        }
                    }
                }
            }
        )
    }

    if (showSetPinDialog) {
        var localPinInput by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showSetPinDialog = false },
            title = { Text("Set 4-digit Security PIN") },
            confirmButton = {
                Button(
                    onClick = {
                        if (localPinInput.length == 4 && localPinInput.all { it.isDigit() }) {
                            viewModel.updatePinCode(localPinInput)
                            viewModel.updatePinLockEnabled(true)
                            showSetPinDialog = false
                        } else {
                            pinError = "PIN must be exactly 4 digits."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue)
                ) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSetPinDialog = false }) {
                    Text("Cancel")
                }
            },
            text = {
                Column {
                    Text(
                        "Please enter a secure 4-digit PIN that you will use to log in next time.",
                        modifier = Modifier.padding(bottom = 12.dp),
                        fontSize = 14.sp
                    )
                    OutlinedTextField(
                        value = localPinInput,
                        onValueChange = {
                            if (it.length <= 4 && it.all { ch -> ch.isDigit() }) {
                                localPinInput = it
                                pinError = null
                            }
                        },
                        label = { Text("Enter 4-digit PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError != null) {
                        Text(pinError!!, color = Color.Red, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        )
    }

    if (showRegisterBiometricsDialog) {
        AlertDialog(
            onDismissRequest = { 
                if (!isRegisteringBiometrics) showRegisterBiometricsDialog = false 
            },
            title = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.Fingerprint,
                        contentDescription = "Scan Icon",
                        tint = SbiLightBlue,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        if (isRegisteringBiometrics) "Scanning Face/Fingerprint..." else "Biometrics Registered!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                if (!isRegisteringBiometrics) {
                    Button(
                        onClick = {
                            viewModel.updateBiometricsEnabled(true)
                            showRegisterBiometricsDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue)
                    ) {
                        Text("Finish Setup")
                    }
                }
            },
            dismissButton = {
                if (!isRegisteringBiometrics) {
                    TextButton(onClick = { showRegisterBiometricsDialog = false }) {
                        Text("Cancel")
                    }
                }
            },
            text = {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    if (isRegisteringBiometrics) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = SbiLightBlue, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Place your finger on the sensor or scan your face to authorize Easy NetBanking.", textAlign = TextAlign.Center, fontSize = 13.sp)
                        }
                    } else {
                        Text("Biometric template successfully registered on this secure device.", textAlign = TextAlign.Center, fontSize = 13.sp)
                    }
                }
            }
        )
    }

}

@Composable
fun PreferenceRowToggle(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = SbiLightBlue,
                    modifier = Modifier
                        .size(36.dp)
                        .background(SbiLightBlue.copy(alpha = 0.1f), CircleShape)
                        .padding(8.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(subtitle, fontSize = 11.sp, color = Color.Gray)
                }
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = SbiLightBlue,
                    checkedTrackColor = SbiLightBlue.copy(alpha = 0.4f)
                )
            )
        }
    }
}

@Composable
fun PreferenceRowClickable(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .debouncedClickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = SbiLightBlue,
                    modifier = Modifier
                        .size(36.dp)
                        .background(SbiLightBlue.copy(alpha = 0.1f), CircleShape)
                        .padding(8.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(subtitle, fontSize = 11.sp, color = Color.Gray)
                }
            }

            Icon(Icons.Filled.ChevronRight, "Action", tint = Color.Gray)
        }
    }
}

@Composable
fun TechStackItem(
    title: String,
    details: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(iconColor.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = title, tint = iconColor, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = iconColor
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = details,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                lineHeight = 15.sp
            )
        }
    }
}
