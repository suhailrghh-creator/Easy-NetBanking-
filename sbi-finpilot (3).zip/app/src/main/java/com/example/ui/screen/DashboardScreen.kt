package com.example.ui.screen

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview as CameraPreview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.api.LanguageTranslations
import com.example.data.model.Transaction
import com.example.ui.theme.*
import com.example.ui.util.debounced
import com.example.ui.util.debouncedClickable
import com.example.ui.viewmodel.FinPilotViewModel
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val profile by viewModel.userProfile.collectAsState()

    var showAddTxDialog by remember { mutableStateOf(false) }
    var showAllTransactions by remember { mutableStateOf(false) }

    var showScanPayDialog by remember { mutableStateOf(false) }
    var showPayMobileDialog by remember { mutableStateOf(false) }
    var showPayUpiDialog by remember { mutableStateOf(false) }
    var showSelfTransferDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            hasCameraPermission = isGranted
        }
    )

    LaunchedEffect(showScanPayDialog) {
        if (showScanPayDialog && !hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Calculate dynamic totals from transactions
    val incomeTotal = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expenseTotal = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val netSavings = incomeTotal - expenseTotal
    val investmentsTotal = transactions.filter { it.category == "Investment" }.sumOf { it.amount }
    
    // Check for fraud
    val suspiciousTxs = transactions.filter { it.isSuspicious }

    val activeNotifications by viewModel.notifications.collectAsState()

    // Farmer alternative underwriting state
    var showUnderwritingWizard by remember { mutableStateOf(false) }
    var underwritingStep by remember { mutableStateOf(1) } // 1: Form, 2: AI Voice Call, 3: Satellite, 4: Approved

    // Form inputs
    var landlordName by remember { mutableStateOf("Ramesh Kumar (Village Cooperative Leader)") }
    var landlordPhone by remember { mutableStateOf("+91 94421 82193") }
    var plotDetails by remember { mutableStateOf("Kalyanpur Plot B, 2.5 Acres") }
    var cropType by remember { mutableStateOf("Wheat (गेहूँ)") }

    // Voice call states
    var isCallConnected by remember { mutableStateOf(false) }
    var isRecordingTrustProof by remember { mutableStateOf(false) }
    var currentSpeechBubble by remember { mutableStateOf("") }
    var isVoiceSpeechActive by remember { mutableStateOf(false) }

    // Satellite scan states
    var satelliteProgress by remember { mutableStateOf(0.0f) }
    var ndviIndex by remember { mutableStateOf(0.0f) }
    var calculatedYield by remember { mutableStateOf(0.0) }
    var cropMarketValue by remember { mutableStateOf(0.0) }
    var isScanningSatellite by remember { mutableStateOf(false) }

    var wavePhase by remember { mutableStateOf(0f) }
    LaunchedEffect(isCallConnected) {
        if (isCallConnected) {
            while (true) {
                kotlinx.coroutines.delay(30)
                wavePhase += 0.25f
            }
        }
    }

    var radarSweepAngle by remember { mutableStateOf(0f) }
    LaunchedEffect(isScanningSatellite) {
        if (isScanningSatellite) {
            while (true) {
                kotlinx.coroutines.delay(16)
                radarSweepAngle = (radarSweepAngle + 4f) % 360f
            }
        }
    }

    LaunchedEffect(underwritingStep, isCallConnected) {
        if (underwritingStep == 2 && isCallConnected) {
            currentSpeechBubble = "Connecting automated call..."
            isVoiceSpeechActive = false
            kotlinx.coroutines.delay(1500)
            currentSpeechBubble = "Ringing..."
            kotlinx.coroutines.delay(2000)
            
            // Connected
            currentSpeechBubble = "Call Answered. Initializing Easy NetBanking AI Verification..."
            kotlinx.coroutines.delay(2000)
            
            // SBI AI speaks
            isVoiceSpeechActive = true
            currentSpeechBubble = "Easy NetBanking AI: 'Pranaam Ramesh ji. This is Easy NetBanking's autonomous AI. We are verifying a verbal tenancy declaration for Suhail Rahman on Kalyanpur Plot B. Does he rent and cultivate Wheat on this plot?'"
            kotlinx.coroutines.delay(8500)
            
            // Ramesh ji speaks
            isVoiceSpeechActive = false
            isRecordingTrustProof = true
            currentSpeechBubble = "Ramesh ji: 'Haan pranaam. Haanji, Suhail humare Kalyanpur wala plot B jo ki 2.5 acre ka hai, pichle do saal se kheti kar raha hai. Bahut hi bhalas kisan hai, imandar hai.'"
            kotlinx.coroutines.delay(8000)
            
            // SBI AI speaks
            isVoiceSpeechActive = true
            isRecordingTrustProof = false
            currentSpeechBubble = "Easy NetBanking AI: 'Thank you Ramesh ji. Your verbal confirmation has been securely recorded on the blockchain as high-confidence digital trust proof. Have a great day.'"
            kotlinx.coroutines.delay(5500)
            
            // Finalizing
            isVoiceSpeechActive = false
            currentSpeechBubble = "Session Closed. Trust proof successfully locked!"
            kotlinx.coroutines.delay(2000)
            underwritingStep = 3
        }
    }

    LaunchedEffect(underwritingStep) {
        if (underwritingStep == 3) {
            isScanningSatellite = true
            satelliteProgress = 0.0f
            ndviIndex = 0.0f
            while (satelliteProgress < 1.0f) {
                kotlinx.coroutines.delay(100)
                satelliteProgress += 0.02f
            }
            isScanningSatellite = false
            ndviIndex = 0.74f // Healthy crop range
            calculatedYield = 4.8 // 4.8 tons
            cropMarketValue = 109200.0 // approx ₹1.09L guarantee asset
            kotlinx.coroutines.delay(2000)
            underwritingStep = 4
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Health Score Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Easy NetBanking",
                        fontSize = 14.sp,
                        color = SbiLightBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Hello, ${profile?.fullName ?: "Customer"}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = { showAddTxDialog = true },
                    modifier = Modifier
                        .background(SbiLightBlue, CircleShape)
                        .size(44.dp)
                ) {
                    Icon(Icons.Filled.Add, "Add Transaction", tint = Color.White)
                }
            }
        }

        // Alternative Credit Underwriting for Tenant Farmers
        item {
            val isFarmerMode = profile?.farmerModeEnabled == true
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("alternative_underwriting_card")
                    .border(
                        width = 1.5.dp,
                        color = if (isFarmerMode) SbiGold.copy(alpha = 0.8f) else SbiLightBlue.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .clickable {
                        // Reset wizard states
                        underwritingStep = 1
                        isCallConnected = false
                        isRecordingTrustProof = false
                        currentSpeechBubble = ""
                        isVoiceSpeechActive = false
                        satelliteProgress = 0.0f
                        showUnderwritingWizard = true
                    },
                colors = CardDefaults.cardColors(
                    containerColor = if (isFarmerMode) SbiGold.copy(alpha = 0.04f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (isFarmerMode) SbiGold.copy(alpha = 0.15f) else SbiLightBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Landscape,
                            contentDescription = "Agricultural Underwriting",
                            tint = if (isFarmerMode) SbiGold else SbiLightBlue,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Farmer No Paper Loan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isFarmerMode) SbiGold else MaterialTheme.colorScheme.onSurface
                            )
                            if (isFarmerMode) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(SbiGold)
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        "ACTIVE MODE",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "No formal land papers or credit score? Verify verbal land tenancy via AI automated Voice Trust & Satellite Crop Health scans for instant credit pre-approval!",
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "👉 Tap to initiate Underwriting Wizard",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isFarmerMode) SbiGold else SbiLightBlue
                            )
                        }
                    }
                }
            }
        }

        // Easy NetBanking UPI Payments Quick Bar (Paytm/GPay style)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                        RoundedCornerShape(20.dp)
                    ),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Easy NetBanking Instant Pay (UPI)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = SbiLightBlue
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "Secure",
                                tint = SbiSuccess,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "NPCI Secure",
                                fontSize = 11.sp,
                                color = SbiSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Scan QR Button
                        UpiActionButton(
                            icon = Icons.Filled.QrCode,
                            label = "Scan QR",
                            color = SbiGold,
                            onClick = { showScanPayDialog = true }
                        )

                        // To Mobile Button
                        UpiActionButton(
                            icon = Icons.Filled.PhoneAndroid,
                            label = "To Mobile",
                            color = SbiLightBlue,
                            onClick = { showPayMobileDialog = true }
                        )

                        // To UPI ID Button
                        UpiActionButton(
                            icon = Icons.Filled.AlternateEmail,
                            label = "To UPI ID",
                            color = SbiLightBlue,
                            onClick = { showPayUpiDialog = true }
                        )

                        // Self Transfer Button
                        UpiActionButton(
                            icon = Icons.Filled.SyncAlt,
                            label = "Self Pay",
                            color = SbiGold,
                            onClick = { showSelfTransferDialog = true }
                        )
                    }
                }
            }
        }

        // Interactive Swipe/Skip Alerts Queue
        if (activeNotifications.isNotEmpty()) {
            item {
                var currentIndex by remember { mutableStateOf(0) }
                if (currentIndex >= activeNotifications.size) {
                    currentIndex = 0
                }
                val currentNotif = activeNotifications[currentIndex.coerceIn(0, activeNotifications.size - 1)]

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = when (currentNotif.priority) {
                                "HIGH" -> SbiError.copy(alpha = 0.5f)
                                "MEDIUM" -> SbiLightBlue.copy(alpha = 0.5f)
                                else -> SbiSuccess.copy(alpha = 0.5f)
                            },
                            shape = RoundedCornerShape(16.dp)
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (currentNotif.type) {
                                        "FRAUD" -> Icons.Filled.Security
                                        "BUDGET" -> Icons.Filled.TrendingDown
                                        "GOAL" -> Icons.Filled.Star
                                        else -> Icons.Filled.Lightbulb
                                    },
                                    contentDescription = "Alert",
                                    tint = when (currentNotif.priority) {
                                        "HIGH" -> SbiError
                                        "MEDIUM" -> SbiLightBlue
                                        else -> SbiSuccess
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = currentNotif.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = when (currentNotif.priority) {
                                        "HIGH" -> SbiError
                                        "MEDIUM" -> SbiLightBlue
                                        else -> SbiSuccess
                                    }
                                )
                            }
                            Text(
                                text = currentNotif.time,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = currentNotif.description,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Alert ${currentIndex + 1} of ${activeNotifications.size}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = {
                                        currentIndex = (currentIndex + 1) % activeNotifications.size
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Filled.SkipNext, "Skip", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Skip", fontSize = 12.sp, color = SbiLightBlue)
                                }

                                Button(
                                    onClick = {
                                        viewModel.dismissNotification(currentNotif.id)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = SbiLightBlue.copy(alpha = 0.15f),
                                        contentColor = SbiLightBlue
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Filled.Check, "Dismiss", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Dismiss", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Fraud Warning Notification
        if (suspiciousTxs.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SbiError.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = SbiError.copy(alpha = 0.08f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = "Alert",
                                tint = SbiError,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                "🚨 AI Fraud Detection Alert",
                                fontWeight = FontWeight.Bold,
                                color = SbiError,
                                fontSize = 15.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Our AI model detected ${suspiciousTxs.size} highly suspicious transaction(s). Please respond immediately:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        suspiciousTxs.forEach { tx ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(0.5.dp, SbiError.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = tx.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            text = "- ₹${String.format("%,.0f", tx.amount)}",
                                            fontWeight = FontWeight.Bold,
                                            color = SbiError,
                                            fontSize = 13.sp
                                        )
                                    }
                                    if (tx.notes.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = tx.notes,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                viewModel.resolveSuspiciousTransaction(tx, isSafe = false)
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = SbiError,
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Filled.Block, "Block", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Block & Refund", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.resolveSuspiciousTransaction(tx, isSafe = true)
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = SbiSuccess,
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Filled.Check, "Recognize", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Recognize Safe", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Financial Health Score & Income/Expenses Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Radial Score Chart Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(180.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = LanguageTranslations.get(language, "health_score"),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SbiLightBlue,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(contentAlignment = Alignment.Center) {
                            val score = profile?.healthScore ?: 78
                            Canvas(modifier = Modifier.size(80.dp)) {
                                drawArc(
                                    color = Color.LightGray.copy(alpha = 0.2f),
                                    startAngle = -90f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = 8.dp.toPx())
                                )
                                drawArc(
                                    color = if (score > 80) SbiSuccess else if (score > 60) SbiLightBlue else SbiError,
                                    startAngle = -90f,
                                    sweepAngle = score * 3.6f,
                                    useCenter = false,
                                    style = Stroke(width = 8.dp.toPx())
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$score",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (score > 80) "Excellent" else if (score > 60) "Good" else "Risky",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }

                // Balance summary
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BalanceStatsCard(
                        title = LanguageTranslations.get(language, "monthly_income"),
                        value = "₹${String.format("%,.0f", incomeTotal)}",
                        icon = Icons.Filled.TrendingUp,
                        color = SbiSuccess
                    )
                    BalanceStatsCard(
                        title = LanguageTranslations.get(language, "monthly_expenses"),
                        value = "₹${String.format("%,.0f", expenseTotal)}",
                        icon = Icons.Filled.TrendingDown,
                        color = SbiError
                    )
                }
            }
        }

        // Analytics Curve Graph
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Cashflow Predictor & Trend Analysis",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SbiLightBlue
                    )
                    Text(
                        "Showing actual vs. AI-predicted next-month cash balance",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Curve Canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    ) {
                        val width = size.width
                        val height = size.height

                        // Grid lines
                        val stepY = height / 3
                        for (i in 0..3) {
                            val y = i * stepY
                            drawLine(
                                color = Color.Gray.copy(alpha = 0.1f),
                                start = Offset(0f, y),
                                end = Offset(width, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Drawing curved paths
                        val points = listOf(
                            Offset(0f, height * 0.8f),
                            Offset(width * 0.25f, height * 0.65f),
                            Offset(width * 0.5f, height * 0.45f),
                            Offset(width * 0.75f, height * 0.3f),
                            Offset(width, height * 0.2f)
                        )

                        val path = Path().apply {
                            moveTo(points[0].x, points[0].y)
                            for (i in 1 until points.size) {
                                val prev = points[i - 1]
                                val curr = points[i]
                                cubicTo(
                                    (prev.x + curr.x) / 2, prev.y,
                                    (prev.x + curr.x) / 2, curr.y,
                                    curr.x, curr.y
                                )
                            }
                        }

                        // Draw Path line
                        drawPath(
                            path = path,
                            color = SbiLightBlue,
                            style = Stroke(width = 3.dp.toPx())
                        )

                        // Predicted dashed line extension
                        drawLine(
                            color = SbiGold,
                            start = points[3],
                            end = Offset(width, height * 0.1f),
                            strokeWidth = 3.dp.toPx()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Week 1", fontSize = 9.sp, color = Color.Gray)
                        Text("Week 2", fontSize = 9.sp, color = Color.Gray)
                        Text("Week 3", fontSize = 9.sp, color = Color.Gray)
                        Text("Week 4", fontSize = 9.sp, color = Color.Gray)
                        Text("Next Month (AI)", fontSize = 9.sp, color = SbiGold, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Loans, Limits & Savings
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Liability & Limits Tracker",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    HorizontalProgressBar(
                        title = "Easy NetBanking Platinum Credit Card Limit (₹1,50,000 max)",
                        ratio = 0.23f,
                        color = SbiGold,
                        valueLabel = "₹34,500 used"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    HorizontalProgressBar(
                        title = "Home Loan Principal Left (₹25L loan)",
                        ratio = 0.78f,
                        color = SbiLightBlue,
                        valueLabel = "₹19,50,000 remaining"
                    )
                }
            }
        }

        // AI Insights Header
        item {
            Text(
                text = LanguageTranslations.get(language, "ai_insights"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = SbiLightBlue
            )
        }

        // AI Insight Carousel Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.currentTab.value = 2 },
                colors = CardDefaults.cardColors(
                    containerColor = SbiLightBlue.copy(alpha = 0.08f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "AI",
                        tint = SbiGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            "AI Cashflow Risk Prediction",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            "Your Swiggy Swell dining expenses increased by 14% this week. " +
                                    "Easy NetBanking suggests putting ₹5,000 in Easy NetBanking Sovereign Gold Bonds immediately to lock liquidity and gain steady returns.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "👉 Tap to plan simulated investment",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SbiLightBlue
                        )
                    }
                }
            }
        }

        // Recent Transactions List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LanguageTranslations.get(language, "recent_tx"),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "See All",
                    color = SbiLightBlue,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { showAllTransactions = true }
                )
            }
        }

        val displayedTransactions = transactions.take(5)

        items(displayedTransactions) { tx ->
            TransactionItemRow(tx)
        }
    }

    // Full-page scrollable Ledger Dialog
    if (showAllTransactions) {
        var searchQuery by remember { mutableStateOf("") }
        var selectedCategory by remember { mutableStateOf("All") }
        var selectedType by remember { mutableStateOf("All") } // "All", "INCOME", "EXPENSE"

        val categories = listOf("All", "Salary", "Groceries", "Dining", "Investment", "Bills", "Utilities", "EMI/Loan", "Rent", "Shopping", "Travel", "Health", "Entertainment", "Others")

        val filteredTransactions = remember(transactions, searchQuery, selectedCategory, selectedType) {
            transactions.filter { tx ->
                val matchesSearch = tx.title.contains(searchQuery, ignoreCase = true) ||
                        tx.category.contains(searchQuery, ignoreCase = true) ||
                        (tx.notes?.contains(searchQuery, ignoreCase = true) == true)
                val matchesCategory = selectedCategory == "All" || tx.category.equals(selectedCategory, ignoreCase = true)
                val matchesType = selectedType == "All" || tx.type.equals(selectedType, ignoreCase = true)

                matchesSearch && matchesCategory && matchesType
            }
        }

        Dialog(
            onDismissRequest = { showAllTransactions = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                ) {
                    // Top Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = { showAllTransactions = false },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.1f), CircleShape)
                        ) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = SbiLightBlue)
                        }
                        Text(
                            text = "Prati Bimb Ledger",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = SbiLightBlue
                        )
                        Box(modifier = Modifier.size(40.dp)) // spacer
                    }

                    // Search and Filter Bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        placeholder = { Text("Search transactions...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SbiLightBlue,
                            unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Type Filter Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("All", "INCOME", "EXPENSE").forEach { type ->
                            val isSelected = selectedType == type
                            val label = when (type) {
                                "INCOME" -> "Inflow"
                                "EXPENSE" -> "Outflow"
                                else -> "All"
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) SbiLightBlue else MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                                    .border(1.dp, if (isSelected) SbiLightBlue else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                    .clickable { selectedType = type }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Category Filter Scrollable Chips
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(categories) { cat ->
                            val isSelected = selectedCategory == cat
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (isSelected) SbiGold else MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                                    .border(1.dp, if (isSelected) SbiGold else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
                                    .clickable { selectedCategory = cat }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = cat,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Transactions Scrollable List
                    if (filteredTransactions.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Inbox,
                                contentDescription = "No transactions",
                                tint = Color.Gray,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No transactions found", fontWeight = FontWeight.Bold, color = Color.Gray)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentPadding = PaddingValues(bottom = 24.dp, start = 16.dp, end = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Text(
                                    text = "${filteredTransactions.size} transactions listed",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                            items(filteredTransactions) { tx ->
                                TransactionItemRow(tx)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Transaction Dialog
    if (showAddTxDialog) {
        var txTitle by remember { mutableStateOf("") }
        var txAmount by remember { mutableStateOf("") }
        var txType by remember { mutableStateOf("EXPENSE") }
        var txCategory by remember { mutableStateOf("Groceries") }
        var txNotes by remember { mutableStateOf("") }

        val categories = listOf("Salary", "Groceries", "Dining", "Investment", "Bills", "Utilities", "EMI/Loan", "Rent", "Shopping")

        AlertDialog(
            onDismissRequest = { showAddTxDialog = false },
            title = { Text("Add Transaction") },
            confirmButton = {
                Button(
                    onClick = debounced {
                        val amt = txAmount.toDoubleOrNull() ?: 0.0
                        if (txTitle.isNotBlank() && amt > 0.0) {
                            viewModel.addTransaction(txTitle, amt, txType, txCategory, txNotes)
                            showAddTxDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue)
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = debounced { showAddTxDialog = false }) {
                    Text("Cancel")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = txTitle,
                        onValueChange = { txTitle = it },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = txAmount,
                        onValueChange = { txAmount = it },
                        label = { Text("Amount (₹)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { txType = "EXPENSE" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (txType == "EXPENSE") SbiError else Color.Gray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Debit (-)")
                        }
                        Button(
                            onClick = { txType = "INCOME" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (txType == "INCOME") SbiSuccess else Color.Gray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Credit (+)")
                        }
                    }

                    Text("Category", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    // Simple category pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SbiLightBlue.copy(alpha = 0.2f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(txCategory, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SbiLightBlue)
                        }
                    }
                    // Selection grids
                    Column {
                        categories.chunked(3).forEach { rowCats ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                rowCats.forEach { cat ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (txCategory == cat) SbiLightBlue else Color.LightGray.copy(alpha = 0.1f))
                                            .debouncedClickable { txCategory = cat }
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            cat,
                                            fontSize = 11.sp,
                                            color = if (txCategory == cat) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }

                    OutlinedTextField(
                        value = txNotes,
                        onValueChange = { txNotes = it },
                        label = { Text("Notes (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        )
    }

    // Alternative Underwriting Wizard Dialog
    if (showUnderwritingWizard) {
        Dialog(
            onDismissRequest = { showUnderwritingWizard = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Title Header with Step Indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Landscape,
                                contentDescription = "Farmer No Paper Loan",
                                tint = SbiGold,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Farmer No Paper Loan Underwriting",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = SbiLightBlue
                            )
                        }
                        IconButton(
                            onClick = { showUnderwritingWizard = false },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.1f), CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = "Close",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step Tracker Visuals
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (step in 1..4) {
                            val isActive = underwritingStep == step
                            val isCompleted = underwritingStep > step
                            val stepColor = if (isActive) SbiGold else if (isCompleted) SbiSuccess else Color.Gray.copy(alpha = 0.3f)
                            
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(stepColor)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("1. Tenancy", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (underwritingStep == 1) SbiGold else Color.Gray)
                        Text("2. AI Trust Call", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (underwritingStep == 2) SbiGold else Color.Gray)
                        Text("3. Satellite Crop", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (underwritingStep == 3) SbiGold else Color.Gray)
                        Text("4. Pre-Approval", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (underwritingStep == 4) SbiGold else Color.Gray)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Content based on steps
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        when (underwritingStep) {
                            1 -> {
                                Text(
                                    text = "Step 1: Verbal Tenancy Declaration",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "If you rent a plot verbally without official registry papers, Easy NetBanking uses alternative validation: P2P Village trust calls and Sentinel-2 satellite scans to issue digital guarantees.",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    lineHeight = 16.sp
                                )
                                Spacer(modifier = Modifier.height(20.dp))

                                OutlinedTextField(
                                    value = landlordName,
                                    onValueChange = { landlordName = it },
                                    label = { Text("Landlord or Cooperative Leader Name") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = landlordPhone,
                                    onValueChange = { landlordPhone = it },
                                    label = { Text("Landlord Mobile Number (for trust validation call)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = plotDetails,
                                    onValueChange = { plotDetails = it },
                                    label = { Text("Verbal Plot Location & Size") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = cropType,
                                    onValueChange = { cropType = it },
                                    label = { Text("Cultivated Crop") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(24.dp))

                                Button(
                                    onClick = {
                                        underwritingStep = 2
                                        isCallConnected = true
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(imageVector = Icons.Filled.Call, contentDescription = "Call")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Initiate Automated AI Verification", fontWeight = FontWeight.Bold)
                                }
                            }
                            2 -> {
                                Text(
                                    text = "Step 2: Voice Verification Call",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Easy NetBanking AI is conducting a live automated call to your village validator to record digital proof of trust.",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(20.dp))

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(10.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isCallConnected) SbiSuccess else SbiError)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = if (isCallConnected) "CALL ACTIVE" else "CONNECTING",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isCallConnected) SbiSuccess else SbiError
                                                )
                                            }
                                            Text(
                                                text = "Validator: $landlordName",
                                                fontSize = 11.sp,
                                                color = Color.White
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(14.dp))

                                        // Pulse Speech Waves on Canvas
                                        Canvas(modifier = Modifier.fillMaxWidth().height(80.dp)) {
                                            val width = size.width
                                            val height = size.height
                                            val midY = height / 2f
                                            val path1 = Path()
                                            val path2 = Path()
                                            
                                            path1.moveTo(0f, midY)
                                            path2.moveTo(0f, midY)
                                            
                                            val amp1 = if (isVoiceSpeechActive || isRecordingTrustProof) 22.dp.toPx() else 4.dp.toPx()
                                            val amp2 = if (isVoiceSpeechActive || isRecordingTrustProof) 12.dp.toPx() else 2.dp.toPx()
                                            
                                            for (x in 0..width.toInt() step 6) {
                                                val radians = (x.toFloat() / width) * 2f * Math.PI.toFloat() * 2.5f + wavePhase
                                                val y1 = midY + Math.sin(radians.toDouble()).toFloat() * amp1
                                                val y2 = midY + Math.cos((radians - 1f).toDouble()).toFloat() * amp2
                                                path1.lineTo(x.toFloat(), y1)
                                                path2.lineTo(x.toFloat(), y2)
                                            }
                                            
                                            drawPath(path1, SbiLightBlue, style = Stroke(width = 2.dp.toPx()))
                                            drawPath(path2, SbiGold, style = Stroke(width = 1.dp.toPx()))
                                        }

                                        Spacer(modifier = Modifier.height(14.dp))

                                        // Real-time scrolling speech dialogue bubble
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.15f))
                                        ) {
                                            Box(modifier = Modifier.padding(12.dp)) {
                                                Text(
                                                    text = currentSpeechBubble,
                                                    fontSize = 12.sp,
                                                    color = if (isRecordingTrustProof) SbiGold else if (isVoiceSpeechActive) SbiLightBlue else Color.White,
                                                    lineHeight = 16.sp,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }
                                        }

                                        if (isRecordingTrustProof) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SbiError))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Securely recording voice trust guarantee...", fontSize = 9.sp, color = SbiError, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Block Proof Hash: enb_vox_${System.currentTimeMillis() % 1000000}",
                                        fontSize = 9.sp,
                                        color = Color.Gray
                                    )
                                    Button(
                                        onClick = {
                                            isCallConnected = false
                                            underwritingStep = 3
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.onSurface)
                                    ) {
                                        Text("Skip to Satellite", fontSize = 11.sp)
                                    }
                                }
                            }
                            3 -> {
                                Text(
                                    text = "Step 3: Open-Source Satellite Scan",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Retrieving Sentinel-2 multispectral band data to calculate Crop Health NDVI Index & predicted future yield.",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(16.dp))

                                // Tactical Radar Plot Canvas
                                Canvas(modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black)) {
                                    val width = size.width
                                    val height = size.height
                                    val centerX = width / 2f
                                    val centerY = height / 2f
                                    
                                    // Draw radar rings
                                    for (r in 1..4) {
                                        drawCircle(
                                            color = SbiSuccess.copy(alpha = 0.2f),
                                            radius = (height / 2.2f) * (r / 4f),
                                            center = Offset(centerX, centerY),
                                            style = Stroke(width = 1.dp.toPx())
                                        )
                                    }
                                    
                                    // Draw grid lines
                                    val cols = 8
                                    val rows = 8
                                    val rectWidth = width / cols
                                    val rectHeight = height / rows

                                    for (i in 0..cols) {
                                        val x = rectWidth * i
                                        drawLine(
                                            color = SbiSuccess.copy(alpha = 0.05f),
                                            start = Offset(x, 0f),
                                            end = Offset(x, height),
                                            strokeWidth = 1.dp.toPx()
                                        )
                                    }
                                    for (i in 0..rows) {
                                        val y = rectHeight * i
                                        drawLine(
                                            color = SbiSuccess.copy(alpha = 0.05f),
                                            start = Offset(0f, y),
                                            end = Offset(width, y),
                                            strokeWidth = 1.dp.toPx()
                                        )
                                    }

                                    // Draw simulated agricultural plots (light up based on scan progress)
                                    for (c in 3..5) {
                                        for (rw in 2..4) {
                                            val colorAlpha = if (satelliteProgress > 0.6f) 0.35f else if (satelliteProgress > 0.2f) 0.15f else 0.02f
                                            drawRect(
                                                color = Color(0xFF4CAF50).copy(alpha = colorAlpha),
                                                topLeft = Offset(c * rectWidth + 2.dp.toPx(), rw * rectHeight + 2.dp.toPx()),
                                                size = androidx.compose.ui.geometry.Size(rectWidth - 4.dp.toPx(), rectHeight - 4.dp.toPx())
                                            )
                                        }
                                    }

                                    // Draw sweeping radar line
                                    val radius = height / 2.2f
                                    val angleRad = Math.toRadians(radarSweepAngle.toDouble())
                                    val endX = centerX + Math.cos(angleRad).toFloat() * radius
                                    val endY = centerY + Math.sin(angleRad).toFloat() * radius
                                    drawLine(
                                        color = SbiSuccess.copy(alpha = 0.5f),
                                        start = Offset(centerX, centerY),
                                        end = Offset(endX, endY),
                                        strokeWidth = 2.dp.toPx()
                                    )
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Scanning Progress Log and Bar
                                Text(
                                    text = if (isScanningSatellite) "🛰️ Orbiting Plot... Sentinel-2 scan at ${String.format("%.0f", satelliteProgress * 100)}%" else "✅ Sentinel-2 Scan Complete!",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isScanningSatellite) SbiGold else SbiSuccess
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { satelliteProgress },
                                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                    color = if (isScanningSatellite) SbiGold else SbiSuccess,
                                    trackColor = Color.Gray.copy(alpha = 0.15f)
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Log feed
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(text = "• Coordinates: Kalyanpur Plot B (26.84° N, 80.94° E)", fontSize = 10.sp, color = Color.Gray)
                                        if (satelliteProgress > 0.25f) {
                                            Text(text = "• Multispectral Band index resolution: Active", fontSize = 10.sp, color = Color.Gray)
                                        }
                                        if (satelliteProgress > 0.5f) {
                                            Text(text = "• Chlorophyll NIR/Red ratio calculated: 0.74 NDVI", fontSize = 10.sp, color = SbiSuccess, fontWeight = FontWeight.Bold)
                                        }
                                        if (satelliteProgress >= 1.0f) {
                                            Text(text = "• Estimated Harvest Yield: 4.8 Metric Tons", fontSize = 10.sp, color = SbiSuccess, fontWeight = FontWeight.Bold)
                                            Text(text = "• Crop Value Guarantee generated: ₹1,09,200", fontSize = 10.sp, color = SbiLightBlue, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                if (!isScanningSatellite) {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Button(
                                        onClick = { underwritingStep = 4 },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Proceed to Pre-Approval", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            4 -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Verified,
                                        contentDescription = "Pre-Approved",
                                        tint = SbiSuccess,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Alternative Underwriting Approved!",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = SbiSuccess,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "We have created bank-grade credit trust out of village voice relationships and satellite crop values.",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 14.dp)
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    // Loan Details Card
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = SbiLightBlue.copy(alpha = 0.05f)),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("Farmer No Paper Loan Certificate", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SbiLightBlue)
                                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Approved Credit Limit", fontSize = 12.sp, color = Color.Gray)
                                                Text("₹80,000", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SbiSuccess)
                                            }
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Dynamic Interest Rate", fontSize = 12.sp, color = Color.Gray)
                                                Text("4.0% p.a.", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Digital Guarantee Asset", fontSize = 12.sp, color = Color.Gray)
                                                Text("Wheat Harvest (₹1,09,200)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Voice Trust Proof", fontSize = 12.sp, color = Color.Gray)
                                                Text("Verified (Leader: $landlordName)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(24.dp))

                                    Button(
                                        onClick = {
                                            viewModel.addTransaction(
                                                title = "Disbursement: Farmer No Paper Loan",
                                                amount = 80000.0,
                                                type = "INCOME",
                                                category = "Salary/Grant",
                                                notes = "Pre-approved Farmer No Paper Loan via peer voice trust proof (Leader: $landlordName) and satellite field scan crop value guarantee."
                                            )
                                            viewModel.boostHealthScore(15) // Boost score by 15 points!
                                            android.widget.Toast.makeText(context, "₹80,000 disbursed instantly to your Easy NetBanking Savings Account!", android.widget.Toast.LENGTH_LONG).show()
                                            showUnderwritingWizard = false
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Disburse ₹80,000 to Easy NetBanking Account", fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    TextButton(onClick = { showUnderwritingWizard = false }) {
                                        Text("Cancel and Save Certificate")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 1. Scan QR Dialog
    if (showScanPayDialog) {
        var scanStage by remember { mutableStateOf("SCANNING") } // "SCANNING", "PAYING", "SUCCESS"
        var payeeName by remember { mutableStateOf("") }
        var payeeUpi by remember { mutableStateOf("") }
        var amountText by remember { mutableStateOf("") }
        var upiPin by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showScanPayDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.QrCode, "QR Pay", tint = SbiGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Easy NetBanking Scan & Pay")
                }
            },
            confirmButton = {
                if (scanStage == "PAYING") {
                    Button(
                        onClick = debounced {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            if (amt > 0.0 && upiPin.length == 6) {
                                viewModel.addTransaction(
                                    title = "UPI Transfer to $payeeName",
                                    amount = amt,
                                    type = "EXPENSE",
                                    category = "Shopping",
                                    notes = "Instant UPI pay to QR code. Ref ID: ${System.currentTimeMillis() % 1000000}"
                                )
                                scanStage = "SUCCESS"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiGold),
                        enabled = amountText.isNotBlank() && upiPin.length == 6
                    ) {
                        Text("Confirm Pay (₹$amountText)", fontWeight = FontWeight.Bold)
                    }
                } else if (scanStage == "SUCCESS") {
                    Button(
                        onClick = debounced { showScanPayDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess)
                    ) {
                        Text("Done")
                    }
                }
            },
            dismissButton = {
                if (scanStage != "SUCCESS") {
                    TextButton(onClick = debounced { showScanPayDialog = false }) {
                        Text("Cancel")
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (scanStage == "SCANNING") {
                        if (hasCameraPermission) {
                            Text(
                                "Point camera at any UPI QR code to scan:",
                                fontSize = 12.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black)
                                    .border(2.dp, SbiGold, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    CameraQrScannerView(
                                        onQrCodeScanned = { qrText ->
                                            val parsed = parseUpiUri(qrText)
                                            if (parsed != null) {
                                                payeeUpi = parsed.first
                                                payeeName = parsed.second
                                                if (parsed.third.isNotBlank()) {
                                                    amountText = parsed.third
                                                }
                                            } else {
                                                payeeUpi = qrText
                                                payeeName = "Scanned Merchant QR"
                                            }
                                            scanStage = "PAYING"
                                        },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    LaserAnimation()
                                }
                            }
                        } else {
                            Text(
                                "Camera permission is required to scan live QR codes.",
                                fontSize = 12.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                            Box(
                                modifier = Modifier
                                    .size(200.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.DarkGray.copy(alpha = 0.5f))
                                    .border(1.dp, Color.Gray, RoundedCornerShape(12.dp))
                                    .clickable {
                                        permissionLauncher.launch(Manifest.permission.CAMERA)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(16.dp)
                                ) {
                                    Icon(Icons.Filled.CameraAlt, "Camera", tint = Color.LightGray, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Grant Camera Permission", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SbiLightBlue, textAlign = TextAlign.Center)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Or tap a quick simulator merchant below:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    payeeName = "Sharma Kirana Store"
                                    payeeUpi = "sharma@easynetbanking"
                                    amountText = "350.0"
                                    scanStage = "PAYING"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue.copy(alpha = 0.15f), contentColor = SbiLightBlue),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(4.dp)
                            ) {
                                Text("Sharma Kirana (₹350)", fontSize = 10.sp, textAlign = TextAlign.Center)
                            }
                            
                            Button(
                                onClick = {
                                    payeeName = "Kolkata Chai Corner"
                                    payeeUpi = "chaicorner@upi"
                                    amountText = "45.0"
                                    scanStage = "PAYING"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue.copy(alpha = 0.15f), contentColor = SbiLightBlue),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(4.dp)
                            ) {
                                Text("Chai Corner (₹45)", fontSize = 10.sp, textAlign = TextAlign.Center)
                            }
                        }
                    } else if (scanStage == "PAYING") {
                        Text("Merchant: $payeeName", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SbiLightBlue)
                        Text("UPI ID: $payeeUpi", fontSize = 12.sp, color = Color.Gray)
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Amount (₹)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SbiGold)
                        )

                        OutlinedTextField(
                            value = upiPin,
                            onValueChange = { if (it.length <= 6) upiPin = it },
                            label = { Text("Enter 6-digit UPI PIN") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SbiGold)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Success",
                            tint = SbiSuccess,
                            modifier = Modifier.size(72.dp)
                        )
                        Text("Payment Successful!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = SbiSuccess)
                        Text("₹$amountText successfully transferred to $payeeName.", textAlign = TextAlign.Center, fontSize = 13.sp)
                    }
                }
            }
        )
    }

    // 2. Pay Mobile Dialog
    if (showPayMobileDialog) {
        var step by remember { mutableStateOf("INPUT") } // "INPUT", "SUCCESS"
        var phoneNo by remember { mutableStateOf("") }
        var payeeName by remember { mutableStateOf("") }
        var amountText by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPayMobileDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PhoneAndroid, "UPI Pay", tint = SbiLightBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("UPI Mobile Transfer")
                }
            },
            confirmButton = {
                if (step == "INPUT") {
                    Button(
                        onClick = debounced {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            if (amt > 0.0 && phoneNo.length == 10 && payeeName.isNotBlank()) {
                                viewModel.addTransaction(
                                    title = "UPI to $payeeName ($phoneNo)",
                                    amount = amt,
                                    type = "EXPENSE",
                                    category = "Shopping",
                                    notes = if (notes.isBlank()) "Mobile Transfer" else notes
                                )
                                step = "SUCCESS"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                        enabled = phoneNo.length == 10 && payeeName.isNotBlank() && (amountText.toDoubleOrNull() ?: 0.0) > 0.0
                    ) {
                        Text("Send Money", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = debounced { showPayMobileDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess)
                    ) {
                        Text("Done")
                    }
                }
            },
            dismissButton = {
                if (step != "SUCCESS") {
                    TextButton(onClick = debounced { showPayMobileDialog = false }) {
                        Text("Cancel")
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (step == "INPUT") {
                        OutlinedTextField(
                            value = phoneNo,
                            onValueChange = { if (it.length <= 10) phoneNo = it },
                            label = { Text("10-Digit Mobile Number") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = payeeName,
                            onValueChange = { payeeName = it },
                            label = { Text("Contact Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Amount (₹)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Notes (Optional)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Success",
                                tint = SbiSuccess,
                                modifier = Modifier.size(72.dp)
                            )
                            Text("Transaction Approved!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = SbiSuccess)
                            Text("₹$amountText paid securely to $payeeName ($phoneNo).", textAlign = TextAlign.Center, fontSize = 13.sp)
                        }
                    }
                }
            }
        )
    }

    // 3. Pay UPI Dialog
    if (showPayUpiDialog) {
        var step by remember { mutableStateOf("INPUT") } // "INPUT", "SUCCESS"
        var upiId by remember { mutableStateOf("") }
        var payeeName by remember { mutableStateOf("") }
        var amountText by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPayUpiDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AlternateEmail, "UPI Pay ID", tint = SbiLightBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("UPI ID Transfer")
                }
            },
            confirmButton = {
                if (step == "INPUT") {
                    Button(
                        onClick = debounced {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            if (amt > 0.0 && upiId.contains("@") && payeeName.isNotBlank()) {
                                viewModel.addTransaction(
                                    title = "UPI ID pay to $payeeName",
                                    amount = amt,
                                    type = "EXPENSE",
                                    category = "Shopping",
                                    notes = if (notes.isBlank()) "UPI ID Transfer ($upiId)" else notes
                                )
                                step = "SUCCESS"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                        enabled = upiId.contains("@") && payeeName.isNotBlank() && (amountText.toDoubleOrNull() ?: 0.0) > 0.0
                    ) {
                        Text("Send Money", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = debounced { showPayUpiDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess)
                    ) {
                        Text("Done")
                    }
                }
            },
            dismissButton = {
                if (step != "SUCCESS") {
                    TextButton(onClick = debounced { showPayUpiDialog = false }) {
                        Text("Cancel")
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (step == "INPUT") {
                        OutlinedTextField(
                            value = upiId,
                            onValueChange = { upiId = it },
                            label = { Text("UPI ID (e.g., payee@easynetbanking)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = payeeName,
                            onValueChange = { payeeName = it },
                            label = { Text("Payee Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Amount (₹)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Notes (Optional)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Success",
                                tint = SbiSuccess,
                                modifier = Modifier.size(72.dp)
                            )
                            Text("Transaction Approved!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = SbiSuccess)
                            Text("₹$amountText paid securely to $payeeName ($upiId).", textAlign = TextAlign.Center, fontSize = 13.sp)
                        }
                    }
                }
            }
        )
    }

    // 4. Self Transfer Dialog
    if (showSelfTransferDialog) {
        var step by remember { mutableStateOf("INPUT") } // "INPUT", "SUCCESS"
        var selectedAccountTo by remember { mutableStateOf("Easy NetBanking Fixed Deposit") }
        var amountText by remember { mutableStateOf("") }
        
        val accounts = listOf("Easy NetBanking Fixed Deposit", "Easy NetBanking Sovereign Gold Bonds", "Easy NetBanking High-Yield Mutual Fund")

        AlertDialog(
            onDismissRequest = { showSelfTransferDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SyncAlt, "Self Transfer", tint = SbiGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Easy NetBanking Self Fund Transfer")
                }
            },
            confirmButton = {
                if (step == "INPUT") {
                    Button(
                        onClick = debounced {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            if (amt > 0.0) {
                                viewModel.addTransaction(
                                    title = "Funded $selectedAccountTo",
                                    amount = amt,
                                    type = "EXPENSE",
                                    category = "Investment",
                                    notes = "Transferred from Easy NetBanking Checking account to investment portfolio."
                                )
                                step = "SUCCESS"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiGold),
                        enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0.0
                    ) {
                        Text("Confirm Transfer", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = debounced { showSelfTransferDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess)
                    ) {
                        Text("Done")
                    }
                }
            },
            dismissButton = {
                if (step != "SUCCESS") {
                    TextButton(onClick = debounced { showSelfTransferDialog = false }) {
                        Text("Cancel")
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (step == "INPUT") {
                        Text("Transfer From: Easy NetBanking Savings Checking Account", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = SbiLightBlue)
                        Text("Select Destination Account Portfolio:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            accounts.forEach { acc ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selectedAccountTo == acc) SbiGold.copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.15f))
                                        .border(1.dp, if (selectedAccountTo == acc) SbiGold else Color.Transparent, RoundedCornerShape(8.dp))
                                        .clickable { selectedAccountTo = acc }
                                        .padding(12.dp)
                                ) {
                                    Text(acc, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selectedAccountTo == acc) SbiGold else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Amount (₹)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Success",
                                tint = SbiSuccess,
                                modifier = Modifier.size(72.dp)
                            )
                            Text("Transfer Complete!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = SbiSuccess)
                            Text("₹$amountText successfully allocated to $selectedAccountTo. Your financial health score and investment trackers have been updated accordingly.", textAlign = TextAlign.Center, fontSize = 13.sp)
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun BalanceStatsCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.1f), CircleShape)
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun HorizontalProgressBar(title: String, ratio: Float, color: Color, valueLabel: String) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            Text(valueLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { ratio },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = Color.LightGray.copy(alpha = 0.2f)
        )
    }
}

@Composable
fun TransactionItemRow(tx: Transaction) {
    val dateStr = remember(tx.timestamp) {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        sdf.format(Date(tx.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
            .border(
                width = 1.dp,
                color = if (tx.isSuspicious) SbiError.copy(alpha = 0.3f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (tx.type == "INCOME") Icons.Filled.AccountBalanceWallet else Icons.Filled.ShoppingCart,
                contentDescription = tx.category,
                tint = if (tx.isSuspicious) SbiError else SbiLightBlue,
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        if (tx.isSuspicious) SbiError.copy(alpha = 0.1f) else SbiLightBlue.copy(alpha = 0.1f),
                        CircleShape
                    )
                    .padding(10.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = tx.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (tx.isSuspicious) SbiError else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${tx.category} • $dateStr",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }

        Text(
            text = if (tx.type == "INCOME") "+₹${String.format("%,.0f", tx.amount)}" else "-₹${String.format("%,.0f", tx.amount)}",
            fontWeight = FontWeight.Bold,
            color = if (tx.type == "INCOME") SbiSuccess else if (tx.isSuspicious) SbiError else MaterialTheme.colorScheme.onSurface,
            fontSize = 14.sp
        )
    }
}

@Composable
fun LaserAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val translationY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 180f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserPosition"
    )
    Spacer(
        modifier = Modifier
            .fillMaxWidth()
            .height(2.dp)
            .offset(y = translationY.dp)
            .background(SbiGold)
    )
}

@Composable
fun UpiActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .debouncedClickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .background(color.copy(alpha = 0.12f), CircleShape)
                .border(1.dp, color.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun CameraQrScannerView(
    onQrCodeScanned: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }

            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                val preview = CameraPreview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, QrCodeAnalyzer { qrText ->
                            onQrCodeScanned(qrText)
                        })
                    }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageAnalysis
                    )
                } catch (exc: Exception) {
                    Log.e("CameraQrScannerView", "Use case binding failed", exc)
                }
            }, ContextCompat.getMainExecutor(ctx))

            previewView
        },
        modifier = modifier
    )

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }
}

class QrCodeAnalyzer(
    private val onQrCodeScanned: (String) -> Unit
) : ImageAnalysis.Analyzer {
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
    )

    private var isScanning = true

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null && isScanning) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    for (barcode in barcodes) {
                        val rawValue = barcode.rawValue
                        if (rawValue != null) {
                            isScanning = false
                            onQrCodeScanned(rawValue)
                            break
                        }
                    }
                }
                .addOnFailureListener {
                    // Fail gracefully
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }
}

fun parseUpiUri(uriString: String): Triple<String, String, String>? {
    try {
        if (uriString.startsWith("upi://pay", ignoreCase = true)) {
            val uri = android.net.Uri.parse(uriString)
            val pa = uri.getQueryParameter("pa") ?: ""
            val pn = uri.getQueryParameter("pn") ?: ""
            val am = uri.getQueryParameter("am") ?: ""
            return Triple(pa, pn, am)
        }
    } catch (e: Exception) {
        // Fallback
    }
    return null
}
