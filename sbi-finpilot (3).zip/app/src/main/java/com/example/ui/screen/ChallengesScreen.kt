package com.example.ui.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPilotViewModel
import com.example.data.api.LanguageTranslations
import com.example.ui.util.debounced
import com.example.ui.util.debouncedClickable
import com.example.data.model.FinancialChallenge
import com.example.data.model.UserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChallengesScreen(viewModel: FinPilotViewModel) {
    val language by viewModel.selectedLanguage.collectAsState()
    val challenges by viewModel.challenges.collectAsState()
    val profile by viewModel.userProfile.collectAsState()

    // Tab for section inside tools: 0 = Simulators, 1 = Investments, 2 = Challenges, 3 = Banking Profiles
    var selectedSectionTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Top Header
        Text(
            text = LanguageTranslations.get(language, "sim_challenges_title"),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp)
        )
        Text(
            text = LanguageTranslations.get(language, "sim_challenges_desc"),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Section tab bar
        TabRow(
            selectedTabIndex = selectedSectionTab,
            containerColor = Color.Transparent,
            contentColor = SbiLightBlue,
            divider = {}
        ) {
            Tab(
                selected = selectedSectionTab == 0,
                onClick = debounced { selectedSectionTab = 0 },
                text = { Text(LanguageTranslations.get(language, "simulators_tab"), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedSectionTab == 1,
                onClick = debounced { selectedSectionTab = 1 },
                text = { Text(LanguageTranslations.get(language, "investments_tab"), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedSectionTab == 2,
                onClick = debounced { selectedSectionTab = 2 },
                text = { Text(LanguageTranslations.get(language, "challenges_tab"), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedSectionTab == 3,
                onClick = debounced { selectedSectionTab = 3 },
                text = { Text(LanguageTranslations.get(language, "profiles_tab"), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSectionTab) {
                0 -> SimulatorsTab(viewModel)
                1 -> InvestmentsTab(viewModel)
                2 -> ChallengesTab(challenges, viewModel)
                3 -> BankingProfilesTab(profile, viewModel)
            }
        }
    }
}

@Composable
fun SimulatorsTab(viewModel: FinPilotViewModel) {
    val simSaveAmount by viewModel.simSaveAmount.collectAsState()
    val simReduceFood by viewModel.simReduceFood.collectAsState()
    val simLoanAmount by viewModel.simLoanAmount.collectAsState()
    val simResult by viewModel.simResult.collectAsState()
    val isSimLoading by viewModel.isSimLoading.collectAsState()

    val emiLoanAmount by viewModel.emiLoanAmount.collectAsState()
    val emiInterestRate by viewModel.emiInterestRate.collectAsState()
    val emiTenureYears by viewModel.emiTenureYears.collectAsState()
    val emiResult by viewModel.emiResult.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // EMI / Loan Eligibility Calculator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Calculate, "EMI", tint = SbiLightBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Easy NetBanking Smart EMI Calculator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = emiLoanAmount,
                        onValueChange = {
                            viewModel.emiLoanAmount.value = it
                            viewModel.calculateEmi()
                        },
                        label = { Text("Loan Principal (₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = emiInterestRate,
                            onValueChange = {
                                viewModel.emiInterestRate.value = it
                                viewModel.calculateEmi()
                            },
                            label = { Text("Interest Rate (%)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = emiTenureYears,
                            onValueChange = {
                                viewModel.emiTenureYears.value = it
                                viewModel.calculateEmi()
                            },
                            label = { Text("Tenure (Years)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SbiLightBlue.copy(alpha = 0.1f))
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Estimated Monthly EMI Payout", fontSize = 11.sp, color = SbiLightBlue)
                            Text(emiResult, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = SbiLightBlue)
                        }
                    }
                }
            }
        }

        // What-If Decision Simulator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Psychology, "Sim", tint = SbiGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Easy NetBanking What-If Simulator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Text(
                        "Test scenario decisions to see predicted 1-year yield.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = simSaveAmount,
                        onValueChange = { viewModel.simSaveAmount.value = it },
                        label = { Text("Additional Monthly Savings (₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = simReduceFood,
                        onValueChange = { viewModel.simReduceFood.value = it },
                        label = { Text("Food Expense Reduction (₹/mo)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.runWhatIfSimulator() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue)
                    ) {
                        if (isSimLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Text("Generate AI Scenario Simulation", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (simResult.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(SbiGold.copy(alpha = 0.08f))
                                .border(1.dp, SbiGold.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = simResult,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChallengesTab(challenges: List<FinancialChallenge>, viewModel: FinPilotViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(challenges) { challenge ->
            ChallengeItemCard(challenge, viewModel)
        }
    }
}

@Composable
fun ChallengeItemCard(challenge: FinancialChallenge, viewModel: FinPilotViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        challenge.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (challenge.isCompleted) SbiSuccess else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        challenge.description,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }

                if (challenge.isCompleted) {
                    Icon(Icons.Filled.Verified, "Completed", tint = SbiSuccess, modifier = Modifier.size(28.dp))
                } else {
                    IconButton(
                        onClick = {
                            val newProgress = (challenge.progress + 0.1f).coerceAtMost(1.0f)
                            viewModel.updateChallengeProgress(challenge, newProgress)
                        },
                        modifier = Modifier
                            .background(SbiLightBlue.copy(alpha = 0.1f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(Icons.Filled.TrendingUp, "Boost", tint = SbiLightBlue, modifier = Modifier.size(20.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Progress: ${String.format("%.0f", challenge.progress * 100)}%",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Reward: +${challenge.rewardPoints} points",
                    fontSize = 10.sp,
                    color = SbiGold,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { challenge.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (challenge.isCompleted) SbiSuccess else SbiLightBlue,
                trackColor = Color.LightGray.copy(alpha = 0.15f)
            )
        }
    }
}

@Composable
fun BankingProfilesTab(profile: UserProfile?, viewModel: FinPilotViewModel) {
    val modes = listOf(
        Triple("STUDENT", "Student Budget Mode", "Limits entertainment and structures micro-saving goals."),
        Triple("FARMER", "Farmer Finance Mode", "Tailors cashflows for harvest cycles & subsidies."),
        Triple("BUSINESS", "Business Expense Mode", "Separates GST invoices, taxes, and cash reserves."),
        Triple("SENIOR", "Senior Citizen Mode", "Prioritizes high-yield FDs, annuities, & pension health."),
        Triple("FAMILY", "Family Budget Mode", "Collaborative co-budgets for shared household bills.")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SbiLightBlue.copy(alpha = 0.08f))
                    .padding(12.dp)
            ) {
                Text(
                    "Switching active modes will re-calibrate your AI Financial Advisor insights, risk tolerance, and Easy NetBanking product suggestions instantly.",
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = SbiLightBlue
                )
            }
        }

        items(modes) { modeTriple ->
            val (key, title, desc) = modeTriple
            val isEnabled = when (key) {
                "STUDENT" -> profile?.studentModeEnabled ?: false
                "FARMER" -> profile?.farmerModeEnabled ?: false
                "BUSINESS" -> profile?.businessModeEnabled ?: false
                "SENIOR" -> profile?.seniorCitizenModeEnabled ?: false
                "FAMILY" -> profile?.familyModeEnabled ?: false
                else -> false
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isEnabled) SbiLightBlue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(desc, fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { viewModel.updateProfileMode(key, it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = SbiLightBlue, checkedTrackColor = SbiLightBlue.copy(alpha = 0.4f))
                    )
                }
            }
        }
    }
}

@Composable
fun InvestmentsTab(viewModel: FinPilotViewModel) {
    val options = remember {
        listOf(
            InvestmentOption(
                id = "sgb",
                name = "Easy NetBanking Sovereign Gold Bonds",
                returnRate = 8.5,
                riskLevel = "Sovereign",
                riskColor = SbiSuccess,
                category = "Sovereign Bond",
                desc = "Government backed gold investment. Extra 2.5% assured interest p.a.",
                icon = Icons.Filled.Stars
            ),
            InvestmentOption(
                id = "bluechip",
                name = "Easy NetBanking Bluechip Equity Fund",
                returnRate = 14.5,
                riskLevel = "High",
                riskColor = SbiError,
                category = "Mutual Fund",
                desc = "Diversified large-cap equity fund targeting consistent compound growth.",
                icon = Icons.Filled.TrendingUp
            ),
            InvestmentOption(
                id = "smart_fd",
                name = "Easy NetBanking Smart High-Yield FD",
                returnRate = 7.1,
                riskLevel = "Low",
                riskColor = SbiSuccess,
                category = "Fixed Deposit",
                desc = "Stable fixed rate returns. Assured maturity value with zero market risk.",
                icon = Icons.Filled.Lock
            ),
            InvestmentOption(
                id = "nps",
                name = "Easy NetBanking Pension NPS Scheme",
                returnRate = 10.2,
                riskLevel = "Medium",
                riskColor = SbiGold,
                category = "Retirement Fund",
                desc = "Tax-saving national pension scheme targeting long-term retirement wealth.",
                icon = Icons.Filled.WorkspacePremium
            ),
            InvestmentOption(
                id = "gilt",
                name = "Easy NetBanking Magnum Gilt Fund",
                returnRate = 8.8,
                riskLevel = "Medium",
                riskColor = SbiGold,
                category = "Debt Fund",
                desc = "Investment in high-grade Government Securities for safe liquid yield.",
                icon = Icons.Filled.Shield
            )
        )
    }

    var selectedIndex by remember { mutableIntStateOf(0) }
    val selectedOption = options[selectedIndex]

    var isSipMode by remember { mutableStateOf(true) }
    var investAmountInput by remember { mutableStateOf("5000") }
    var tenureYears by remember { mutableIntStateOf(5) }

    var showAuthDialog by remember { mutableStateOf(false) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var upiPin by remember { mutableStateOf("") }
    var selectedAccount by remember { mutableStateOf("Easy NetBanking Savings Account (xxxx3491)") }

    val amountDouble = investAmountInput.toDoubleOrNull() ?: 0.0

    // Maturity Calculations
    val totalInvested = if (isSipMode) {
        amountDouble * 12 * tenureYears
    } else {
        amountDouble
    }

    val maturityAmount = if (isSipMode) {
        val i = (selectedOption.returnRate / 100) / 12
        val n = tenureYears * 12
        if (i == 0.0) totalInvested
        else amountDouble * ((Math.pow(1 + i, n.toDouble()) - 1) / i) * (1 + i)
    } else {
        amountDouble * Math.pow(1 + (selectedOption.returnRate / 100), tenureYears.toDouble())
    }

    val estReturns = (maturityAmount - totalInvested).coerceAtLeast(0.0)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Option cards selection header
        item {
            Text(
                text = "1. Select Easy NetBanking Investment Option",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = SbiLightBlue,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        // Horizontally Scrollable / Grid of Investment options
        item {
            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(options.size) { index ->
                    val option = options[index]
                    val isSelected = index == selectedIndex
                    Card(
                        modifier = Modifier
                            .width(200.dp)
                            .height(180.dp)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) SbiLightBlue else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { selectedIndex = index },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) SbiLightBlue.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(SbiLightBlue.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = option.icon,
                                        contentDescription = option.name,
                                        tint = SbiLightBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(option.riskColor.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = option.riskLevel,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = option.riskColor
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = option.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    lineHeight = 16.sp,
                                    maxLines = 2
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = option.category,
                                    fontSize = 10.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Est. Return",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "${option.returnRate}% p.a.",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SbiSuccess
                                )
                            }
                        }
                    }
                }
            }
        }

        // Selected Option descriptive card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SbiLightBlue.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = SbiLightBlue.copy(alpha = 0.03f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = selectedOption.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = SbiLightBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedOption.desc,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // SIP / Lumpsum Interactive Calculator
        item {
            Text(
                text = "2. Customize Investment Plan",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = SbiLightBlue,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                        RoundedCornerShape(16.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Plan mode tab picker
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.2f))
                            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
                            .padding(4.dp)
                    ) {
                        listOf(true to "Monthly SIP", false to "One-time Lumpsum").forEach { (sipMode, label) ->
                            val isSelected = isSipMode == sipMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) SbiLightBlue else Color.Transparent)
                                    .clickable { 
                                        isSipMode = sipMode 
                                        if (sipMode && investAmountInput == "50000") {
                                            investAmountInput = "5000"
                                        } else if (!sipMode && investAmountInput == "5000") {
                                            investAmountInput = "50000"
                                        }
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Amount input field
                    OutlinedTextField(
                        value = investAmountInput,
                        onValueChange = { investAmountInput = it },
                        label = { Text(if (isSipMode) "Monthly Contribution Amount (₹)" else "One-time Lumpsum Amount (₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tenure quick buttons
                    Text(
                        text = "Tenure / Duration",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 3, 5, 10, 15).forEach { yrs ->
                            val isSelected = tenureYears == yrs
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) SbiGold else MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                                    .border(1.dp, if (isSelected) SbiGold else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                    .clickable { tenureYears = yrs }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$yrs ${if (yrs == 1) "Yr" else "Yrs"}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Calculations display card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SbiLightBlue.copy(alpha = 0.06f))
                            .border(0.5.dp, SbiLightBlue.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Invested Amount", fontSize = 12.sp, color = Color.Gray)
                                Text("₹${String.format("%,.0f", totalInvested)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Est. Interest Return", fontSize = 12.sp, color = Color.Gray)
                                Text("₹${String.format("%,.0f", estReturns)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SbiSuccess)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Projected Maturity Value", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("₹${String.format("%,.0f", maturityAmount)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SbiLightBlue)
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Dual progress visual meter
                            val profitRatio = if (maturityAmount > 0.0) (estReturns / maturityAmount).toFloat() else 0.0f
                            val principalRatio = 1f - profitRatio

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(principalRatio.coerceAtLeast(0.01f))
                                        .background(SbiLightBlue)
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(profitRatio.coerceAtLeast(0.01f))
                                        .background(SbiSuccess)
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SbiLightBlue))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Principal (${String.format("%.0f", principalRatio * 100)}%)", fontSize = 9.sp, color = Color.Gray)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SbiSuccess))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Profits (${String.format("%.0f", profitRatio * 100)}%)", fontSize = 9.sp, color = SbiSuccess, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Invest Commit Action
                    Button(
                        onClick = debounced {
                            if (amountDouble > 0.0) {
                                showAuthDialog = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.Security, contentDescription = "Invest")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Initiate Simulated Investment",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }

    // AUTH / PAYMENT AUTHORIZATION DIALOG
    if (showAuthDialog) {
        AlertDialog(
            onDismissRequest = { showAuthDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Security, contentDescription = "Auth", tint = SbiLightBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Secure Portal Authorization", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "You are allocating simulated funds from your account to purchase:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = selectedOption.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = SbiLightBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Type: ${if (isSipMode) "Monthly SIP" else "One-time Lumpsum"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Amount: ₹${String.format("%,.0f", amountDouble)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = SbiSuccess
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Debit Account",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    listOf(
                        "Easy NetBanking Savings Account (xxxx3491)",
                        "Easy NetBanking Corporate Salary (xxxx8127)"
                    ).forEach { acc ->
                        val isAccSelected = selectedAccount == acc
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedAccount = acc }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isAccSelected,
                                onClick = { selectedAccount = acc },
                                colors = RadioButtonDefaults.colors(selectedColor = SbiLightBlue)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(acc, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = upiPin,
                        onValueChange = { if (it.length <= 6) upiPin = it },
                        label = { Text("Enter 6-Digit Security PIN") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SbiLightBlue)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = debounced {
                        if (upiPin.length == 6) {
                            showAuthDialog = false
                            // Add programmatically to transactions
                            viewModel.addTransaction(
                                title = "Simulated Buy: ${selectedOption.name}",
                                amount = amountDouble,
                                type = "EXPENSE",
                                category = "Investment",
                                notes = "Smart Easy NetBanking simulated portfolio allocation for ${tenureYears} Years at ${selectedOption.returnRate}%."
                            )
                            showSuccessDialog = true
                            upiPin = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SbiSuccess)
                ) {
                    Text("Authorize & Buy")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAuthDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // SUCCESS PORTFOLIO ALLOCATION RECEIPT
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            title = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Success",
                        tint = SbiSuccess,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Investment Success",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = SbiSuccess
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Easy NetBanking secure purchase ledger verified.",
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = selectedOption.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SbiLightBlue,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Plan Type:", fontSize = 11.sp, color = Color.Gray)
                                Text(if (isSipMode) "Monthly SIP" else "Lumpsum", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Amount Debit:", fontSize = 11.sp, color = Color.Gray)
                                Text("₹${String.format("%,.0f", amountDouble)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SbiSuccess)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Txn Ref:", fontSize = 11.sp, color = Color.Gray)
                                Text("ENB-PB-${System.currentTimeMillis() % 1000000}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Your investment total has been updated on the main dashboard screen.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = debounced {
                        showSuccessDialog = false
                        viewModel.currentTab.value = 0 // Return to dashboard to see updated investments total!
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SbiLightBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Go to Dashboard", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

data class InvestmentOption(
    val id: String,
    val name: String,
    val returnRate: Double,
    val riskLevel: String,
    val riskColor: Color,
    val category: String,
    val desc: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
